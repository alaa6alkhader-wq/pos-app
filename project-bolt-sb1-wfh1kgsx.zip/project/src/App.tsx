
import React, { useState, useEffect, useMemo } from 'react';

// ==========================================
// 1. المساعدات الحسابية والمالية الصارمة
// ==========================================

export function round2(val: number): number {
  return Math.round((val + Number.EPSILON) * 100) / 100;
}

export function parseDecimal(val: any): number {
  if (val === undefined || val === null || val === '') return 0;
  if (typeof val === 'number') return isNaN(val) ? 0 : round2(val);
  const cleaned = String(val).replace(/,/g, '.').trim();
  const num = parseFloat(cleaned);
  return isNaN(num) ? 0 : round2(num);
}

export function formatCurr(val: number, curr = 'USD'): string {
  const safeVal = parseDecimal(val);
  const formatted = new Intl.NumberFormat('en-US', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  }).format(safeVal);
  return `${formatted} ${curr === 'USD' ? '$' : 'ل.س'}`;
}

// ==========================================
// 2. هياكل البيانات المحاسبية المتكاملة
// ==========================================
export interface AlAmeenItem {
  id: number;
  code: string;
  name: string;
  category: 'كهربائيات' | 'صحية' | 'خردة' | 'أدوات أخرى';
  baseUnit: 'متر' | 'قطعة' | 'طقم' | 'كيلو غرام';
  subUnitName?: string;
  subUnitFactor?: number;
  subUnitPrice?: number;
  costPrice: number;
  salePrice: number;
  stockQty: number;
  minStock: number;
  rackLocation?: string;
  isDeleted?: boolean;
}

export interface InvoiceRow {
  itemId: number;
  itemCode: string;
  itemName: string;
  unit: string;
  factor: number;
  quantity: number;
  price: number;
  total: number;
  cost: number;
  addedAt?: string;
}

export interface PaymentRecord {
  id: string;
  date: string;
  time: string;
  amount: number;
  notes: string;
  partyName: string;
  partyType: 'customer' | 'merchant';
  invNumber: string;
}

export interface AlAmeenInvoice {
  id: number;
  invNumber: string;
  type: 'sale' | 'purchase' | 'return';
  customerName: string;
  customerPhone: string;
  merchantName?: string;
  shopName?: string;
  rows: InvoiceRow[];
  subTotal: number;
  discount: number;
  grandTotal: number;
  initialPaid: number;
  paidAmount: number;
  remainingAmount: number;
  currency: 'USD' | 'SYP';
  exchangeRate: number;
  invDate: string;
  invTime: string;
  notes?: string;
  origInvNumber?: string;
}

export interface ExpenseItem {
  id: number;
  title: string;
  category: 'كهرباء وإنارة' | 'إيجار المحل' | 'أجور عمال' | 'شحن ونقل' | 'صيانة' | 'نثريات وضيافة';
  amount: number;
  currency: 'USD' | 'SYP';
  date: string;
  time: string;
  notes?: string;
}

export interface AlAmeenSettings {
  shopName: string;
  phone: string;
  address: string;
  usdRate: number;
  adminUsername: string;
  adminPass: string;
  securityQuestion: string;
  securityAnswer: string;
  fontSize: 'normal' | 'medium' | 'large';
  logoBase64?: string;
  logoPosition: 'right' | 'center' | 'left';
  stampBase64?: string;
  signatureBase64?: string;
}

// مفاتيح تخزين مستقرة تماماً تضمن عدم فقدان أي بيانات أثناء التحديثات
const STORAGE_KEYS = {
  ITEMS: 'alameen_storage_items_v2026',
  INVOICES: 'alameen_storage_invoices_v2026',
  PAYMENTS: 'alameen_storage_payments_v2026',
  EXPENSES: 'alameen_storage_expenses_v2026',
  SETTINGS: 'alameen_storage_settings_v2026'
};

function getLocal<T>(key: string, def: T): T {
  try {
    const d = localStorage.getItem(key);
    return d ? JSON.parse(d) : def;
  } catch (err) {
    console.error(`Error loading: ${key}`, err);
    return def;
  }
}

function setLocal<T>(key: string, val: T): void {
  try {
    localStorage.setItem(key, JSON.stringify(val));
  } catch (e) {
    console.error(`Error saving: ${key}`, e);
  }
}

// دالة الطباعة النظيفة المعزولة بدون إنترنت وبدون عناصر الواجهة
function printCleanDocumentOffline(htmlBody: string) {
  const oldFrame = document.getElementById('alameen-clean-print-frame');
  if (oldFrame) oldFrame.remove();

  const iframe = document.createElement('iframe');
  iframe.id = 'alameen-clean-print-frame';
  iframe.style.position = 'fixed';
  iframe.style.right = '0';
  iframe.style.bottom = '0';
  iframe.style.width = '0';
  iframe.style.height = '0';
  iframe.style.border = 'none';
  iframe.style.visibility = 'hidden';
  document.body.appendChild(iframe);

  const frameDoc = iframe.contentWindow || iframe.contentDocument;
  const doc = (frameDoc as any).document || frameDoc;

  doc.open();
  doc.write(`
    <!DOCTYPE html>
    <html dir="rtl" lang="ar">
    <head>
      <meta charset="utf-8">
      <title>طباعة رسمية A4</title>
      <style>
        @page { size: A4 portrait; margin: 12mm; }
        body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Tahoma, Arial, sans-serif; margin: 0; padding: 10px; color: #111; font-size: 13px; line-height: 1.5; direction: rtl; }
        table { width: 100%; border-collapse: collapse; margin-top: 15px; margin-bottom: 15px; }
        th, td { border: 1px solid #333; padding: 8px; text-align: right; }
        th { background-color: #f3f4f6; font-weight: bold; }
        .header { display: flex; justify-content: space-between; align-items: center; border-bottom: 2px solid #222; padding-bottom: 12px; margin-bottom: 15px; }
        .info-box { border: 1px solid #444; padding: 10px; border-radius: 4px; margin-bottom: 15px; display: flex; justify-content: space-between; }
        .notes-box { border: 1px dashed #666; padding: 8px; border-radius: 4px; margin-bottom: 15px; background-color: #fafafa; font-size: 12px; }
        .footer { margin-top: 35px; display: flex; justify-content: space-between; align-items: flex-end; border-top: 1px solid #ccc; padding-top: 15px; }
        .totals-box { width: 280px; margin-right: auto; margin-left: 0; border: 1px solid #333; padding: 8px; font-weight: bold; }
        .totals-row { display: flex; justify-content: space-between; margin-bottom: 4px; }
      </style>
    </head>
    <body>
      ${htmlBody}
    </body>
    </html>
  `);
  doc.close();

  setTimeout(() => {
    try {
      iframe.contentWindow?.focus();
      iframe.contentWindow?.print();
    } catch (err) {
      console.error('Print failed:', err);
    }
  }, 250);
}

// مكتبة الأيقونات المتجهة
const SvgIcons = {
  Cart: () => (
    <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z" />
    </svg>
  ),
  Package: () => (
    <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4" />
    </svg>
  ),
  Debts: () => (
    <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
    </svg>
  ),
  Truck: () => (
    <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8 4H6a2 2 0 00-2 2v12a2 2 0 002 2h12a2 2 0 002-2V6a2 2 0 00-2-2h-2m-4-1v8m0 0l3-3m-3 3L9 8m-5 5h2.586a1 1 0 01.707.293l2.414 2.414a1 1 0 00.707.293h3.172a1 1 0 00.707-.293l2.414-2.414a1 1 0 01.707-.293H20" />
    </svg>
  ),
  MerchantStatement: () => (
    <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
    </svg>
  ),
  MoneyBag: () => (
    <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17 9V7a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2m2 4h10a2 2 0 002-2v-6a2 2 0 00-2-2H9a2 2 0 00-2 2v6a2 2 0 002 2zm7-5a2 2 0 11-4 0 2 2 0 014 0z" />
    </svg>
  ),
  Returns: () => (
    <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
    </svg>
  ),
  Layers: () => (
    <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" />
    </svg>
  ),
  Printer: () => (
    <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17 17h2a2 2 0 002-2v-4a2 2 0 00-2-2H5a2 2 0 00-2 2v4a2 2 0 002 2h2m2 4h6a2 2 0 002-2v-4a2 2 0 00-2-2H9a2 2 0 00-2 2v4a2 2 0 002 2zm8-12V5a2 2 0 00-2-2H9a2 2 0 00-2 2v4h10z" />
    </svg>
  ),
  Trending: () => (
    <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" />
    </svg>
  ),
  Users: () => (
    <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
    </svg>
  ),
  Settings: () => (
    <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" />
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
    </svg>
  )
};

// ==========================================
// 3. التطبيق الرئيسي لبرنامج الأمين
// ==========================================
export default function App() {
  const [currentUser, setCurrentUser] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<
    'sale_inv' | 'pur_inv' | 'unpaid_debts' | 'merchant_debts' | 'merchant_statement' | 'expenses' | 'returns' | 'items' | 'archive' | 'profits' | 'statement' | 'settings'
  >('sale_inv');

  const [items, setItems] = useState<AlAmeenItem[]>([]);
  const [invoices, setInvoices] = useState<AlAmeenInvoice[]>([]);
  const [payments, setPayments] = useState<PaymentRecord[]>([]);
  const [expenses, setExpenses] = useState<ExpenseItem[]>([]);
  const [settings, setSettings] = useState<AlAmeenSettings>({
    shopName: 'مؤسسة النور للأدوات الصحية والكهربائية والخردة',
    phone: '0912345678',
    address: 'الشارع التجاري العام - جانب دوار الساعة',
    usdRate: 15000,
    adminUsername: 'alaa',
    adminPass: '123456',
    securityQuestion: 'ما هو اسم محلك الأول؟',
    securityAnswer: 'النور',
    fontSize: 'normal',
    logoPosition: 'right'
  });

  // نافذة التحقق الأمني من كلمة المرور لتنفيذ الحذف والتعديل
  const [securityModal, setSecurityModal] = useState<{
    isOpen: boolean;
    title: string;
    description: string;
    onSuccess: () => void;
  }>({
    isOpen: false,
    title: '',
    description: '',
    onSuccess: () => {}
  });
  const [inputPass, setInputPass] = useState('');

  // استرجاع البيانات المحفوظة مع حماية من الأخطاء
  useEffect(() => {
    let savedItems = getLocal<AlAmeenItem[]>(STORAGE_KEYS.ITEMS, []);
    let savedInvoices = getLocal<AlAmeenInvoice[]>(STORAGE_KEYS.INVOICES, []);
    let savedPayments = getLocal<PaymentRecord[]>(STORAGE_KEYS.PAYMENTS, []);
    let savedExpenses = getLocal<ExpenseItem[]>(STORAGE_KEYS.EXPENSES, []);
    let savedSettings = getLocal<AlAmeenSettings>(STORAGE_KEYS.SETTINGS, settings);

    if (savedItems.length === 0) {
      savedItems = [
        { id: 1, code: '101', name: 'سلك نحاس معزول 2.5 مم', category: 'كهربائيات', baseUnit: 'متر', subUnitName: 'لفة', subUnitFactor: 100, subUnitPrice: 24, costPrice: 0.18, salePrice: 0.25, stockQty: 850, minStock: 100, rackLocation: 'A-1' },
        { id: 2, code: '102', name: 'قاطع أوتوماتيك شنايدر 32A', category: 'كهربائيات', baseUnit: 'قطعة', costPrice: 3.5, salePrice: 5.0, stockQty: 0, minStock: 15, rackLocation: 'B-2' },
        { id: 3, code: '201', name: 'محبس مياه إيطالي 1/2 إنش', category: 'صحية', baseUnit: 'قطعة', subUnitName: 'كرتونة', subUnitFactor: 24, subUnitPrice: 60, costPrice: 2.0, salePrice: 2.8, stockQty: 120, minStock: 24, rackLocation: 'C-1' },
        { id: 4, code: '301', name: 'نحاس أحمر خردة كابلات', category: 'خردة', baseUnit: 'كيلو غرام', costPrice: 7.5, salePrice: 9.0, stockQty: 18, minStock: 50, rackLocation: 'مستودع الخردة' }
      ];
      setLocal(STORAGE_KEYS.ITEMS, savedItems);
    }

    setItems(savedItems);
    setInvoices(savedInvoices);
    setPayments(savedPayments);
    setExpenses(savedExpenses);
    setSettings(savedSettings);
  }, []);

  const updateItems = (newItems: AlAmeenItem[]) => {
    setItems(newItems);
    setLocal(STORAGE_KEYS.ITEMS, newItems);
  };

  const updateInvoices = (newInvs: AlAmeenInvoice[]) => {
    setInvoices(newInvs);
    setLocal(STORAGE_KEYS.INVOICES, newInvs);
  };

  const updatePayments = (newPayments: PaymentRecord[]) => {
    setPayments(newPayments);
    setLocal(STORAGE_KEYS.PAYMENTS, newPayments);
  };

  const updateExpenses = (newExp: ExpenseItem[]) => {
    setExpenses(newExp);
    setLocal(STORAGE_KEYS.EXPENSES, newExp);
  };

  const updateSettings = (newSet: AlAmeenSettings) => {
    setSettings(newSet);
    setLocal(STORAGE_KEYS.SETTINGS, newSet);
  };

  // دالة طلب كلمة المرور لتنفيذ الإجراءات المحمية
  const requestAdminAuth = (title: string, description: string, onSuccess: () => void) => {
    setInputPass('');
    setSecurityModal({
      isOpen: true,
      title,
      description,
      onSuccess
    });
  };

  const handleVerifyAdminPass = (e: React.FormEvent) => {
    e.preventDefault();
    if (inputPass.trim() === settings.adminPass.trim()) {
      const cb = securityModal.onSuccess;
      setSecurityModal({ isOpen: false, title: '', description: '', onSuccess: () => {} });
      cb();
    } else {
      alert('كلمة مرور المدير غير صحيحة! تم رفض العملية.');
    }
  };

  const activeItems = useMemo(() => items.filter(i => !i.isDeleted), [items]);
  const lowOrOutItems = useMemo(() => activeItems.filter(i => i.stockQty <= i.minStock), [activeItems]);

  const fontSizeClass =
    settings.fontSize === 'large'
      ? 'text-base font-medium'
      : settings.fontSize === 'medium'
      ? 'text-sm'
      : 'text-xs';

  // طباعة الفواتير الرسمية المعزولة مع ترويسة "السيد:"
  const printCleanA4InvoiceOffline = (invoice: AlAmeenInvoice) => {
    const rowsHtml = invoice.rows
      .map(
        (r, i) => `
        <tr>
          <td style="text-align:center;">${i + 1}</td>
          <td>${r.itemCode}</td>
          <td style="font-weight:bold;">${r.itemName}</td>
          <td>${r.unit}</td>
          <td style="text-align:center;">${r.quantity}</td>
          <td>${formatCurr(r.price, invoice.currency)}</td>
          <td style="font-weight:bold;">${formatCurr(r.total, invoice.currency)}</td>
        </tr>
      `
      )
      .join('');

    const logoHtml = settings.logoBase64
      ? `<img src="${settings.logoBase64}" style="height: 65px; object-fit: contain;" />`
      : '';

    const stampHtml = settings.stampBase64
      ? `<img src="${settings.stampBase64}" style="height: 60px; object-fit: contain;" />`
      : '<div style="height: 50px; border: 1px dashed #aaa; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 10px; color: #888;">ختم المؤسسة</div>';

    const sigHtml = settings.signatureBase64
      ? `<img src="${settings.signatureBase64}" style="height: 50px; object-fit: contain;" />`
      : '<div style="height: 40px; border-bottom: 1px dashed #888;"></div>';

    const notesHtml = invoice.notes && invoice.notes.trim()
      ? `<div class="notes-box"><strong>ملاحظات وبيان الفاتورة:</strong><br />${invoice.notes.replace(/\n/g, '<br />')}</div>`
      : '';

    const cleanHtml = `
      <div class="header">
        <div>
          <h1 style="margin: 0; font-size: 20px;">${settings.shopName}</h1>
          <p style="margin: 3px 0; color: #555;">هاتف: ${settings.phone} | العنوان: ${settings.address}</p>
          <h3 style="margin: 5px 0 0 0; color: #333;">${invoice.type === 'sale' ? 'فاتورة مبيعات رسمية' : invoice.type === 'purchase' ? 'فاتورة مشتريات' : 'فاتورة مرتجع'} #${invoice.invNumber}</h3>
        </div>
        <div>${logoHtml}</div>
      </div>

      <div class="info-box">
        <div>
          <p style="margin: 2px 0;"><strong>السيد:</strong> ${invoice.customerName}</p>
          <p style="margin: 2px 0;"><strong>رقم الجوال:</strong> ${invoice.customerPhone}</p>
        </div>
        <div style="text-align: left;">
          <p style="margin: 2px 0;"><strong>التاريخ:</strong> ${invoice.invDate}</p>
          <p style="margin: 2px 0;"><strong>الوقت:</strong> ${invoice.invTime}</p>
        </div>
      </div>

      ${notesHtml}

      <table>
        <thead>
          <tr>
            <th>#</th>
            <th>رمز المادة</th>
            <th>اسم المادة والمواصفة</th>
            <th>الوحدة</th>
            <th>الكمية</th>
            <th>السعر</th>
            <th>الإجمالي</th>
          </tr>
        </thead>
        <tbody>
          ${rowsHtml}
        </tbody>
      </table>

      <div class="totals-box">
        <div class="totals-row"><span>المجموع:</span><span>${formatCurr(invoice.subTotal, invoice.currency)}</span></div>
        <div class="totals-row"><span>الخصم:</span><span>${formatCurr(invoice.discount, invoice.currency)}</span></div>
        <div class="totals-row" style="border-top: 1px solid #444; padding-top: 3px; font-size: 14px;"><span>الصافي:</span><span>${formatCurr(invoice.grandTotal, invoice.currency)}</span></div>
        <div class="totals-row" style="color: green;"><span>المدفوع:</span><span>${formatCurr(invoice.paidAmount, invoice.currency)}</span></div>
        ${invoice.remainingAmount > 0 ? `<div class="totals-row" style="color: red;"><span>المتبقي ذمة:</span><span>${formatCurr(invoice.remainingAmount, invoice.currency)}</span></div>` : ''}
      </div>

      <div class="footer">
        <div style="text-align: center; width: 180px;">
          <p style="margin: 0 0 5px 0; font-weight: bold;">توقيع المستلم / المحاسب</p>
          ${sigHtml}
        </div>
        <div style="text-align: center; width: 180px;">
          <p style="margin: 0 0 5px 0; font-weight: bold;">الختم الرسمي للمؤسسة</p>
          ${stampHtml}
        </div>
      </div>
    `;

    printCleanDocumentOffline(cleanHtml);
  };

  // طباعة كشف حساب الزبون النظيف بدون إنترنت
  const handlePrintCustomerStatement = (customerName: string, customerPhone: string, invoicesList: AlAmeenInvoice[], paymentsList: PaymentRecord[], totalBilled: number, totalPaid: number, totalDebt: number) => {
    let rowsHtml = '';
    invoicesList.forEach(inv => {
      rowsHtml += `
        <tr>
          <td>${inv.invDate} ${inv.invTime}</td>
          <td>${inv.type === 'sale' ? `فاتورة بيع #${inv.invNumber}` : `مرتجع بضاعة #${inv.invNumber}`}</td>
          <td>${inv.rows.map(r => `${r.itemName} (${r.quantity} ${r.unit})`).join('، ')}</td>
          <td>${inv.type === 'sale' ? formatCurr(inv.grandTotal, inv.currency) : '-'}</td>
          <td style="color: green;">${inv.type === 'sale' ? formatCurr(inv.paidAmount, inv.currency) : formatCurr(inv.grandTotal, inv.currency)}</td>
        </tr>
      `;
    });

    paymentsList.forEach(pay => {
      rowsHtml += `
        <tr style="background-color: #f0fdf4;">
          <td>${pay.date} ${pay.time}</td>
          <td style="font-weight: bold; color: green;">سند قبض دفعة دين</td>
          <td>${pay.notes}</td>
          <td>-</td>
          <td style="font-weight: bold; color: green;">+${formatCurr(pay.amount)}</td>
        </tr>
      `;
    });

    const cleanHtml = `
      <div class="header">
        <div>
          <h1 style="margin: 0; font-size: 20px;">${settings.shopName}</h1>
          <p style="margin: 3px 0;">كشف حساب زبون تفصيلي معتمد - التاريخ: ${new Date().toISOString().split('T')[0]}</p>
        </div>
      </div>

      <div class="info-box">
        <div>
          <p style="margin: 2px 0;"><strong>السيد:</strong> ${customerName}</p>
          <p style="margin: 2px 0;"><strong>رقم الجوال:</strong> ${customerPhone}</p>
        </div>
        <div style="text-align: left;">
          <p style="margin: 2px 0;"><strong>إجمالي المسحوبات:</strong> ${formatCurr(totalBilled)}</p>
          <p style="margin: 2px 0; color: green;"><strong>إجمالي المسدد:</strong> ${formatCurr(totalPaid)}</p>
          <p style="margin: 2px 0; font-weight: bold; color: ${totalDebt > 0 ? 'red' : 'green'};">
            ${totalDebt > 0 ? `لنا عند الزبون: ${formatCurr(totalDebt)}` : 'الحساب مسدد بالكامل ✓'}
          </p>
        </div>
      </div>

      <table>
        <thead>
          <tr>
            <th>التاريخ والوقت</th>
            <th>نوع الحركة</th>
            <th>تفاصيل المواد والكميات</th>
            <th>مدين (لنا)</th>
            <th>دائن (له مسدد)</th>
          </tr>
        </thead>
        <tbody>
          ${rowsHtml}
        </tbody>
      </table>
    `;

    printCleanDocumentOffline(cleanHtml);
  };

  // طباعة كشف حساب التاجر النظيف بدون إنترنت
  const handlePrintMerchantStatement = (merchantName: string, entries: any[], totalCredit: number, totalDebit: number, netDue: number) => {
    const rowsHtml = entries
      .map(
        e => `
        <tr>
          <td>${e.date} ${e.time}</td>
          <td style="font-weight: bold;">${e.type}</td>
          <td>${e.ref}</td>
          <td style="color: green; font-weight: bold;">${e.debit > 0 ? formatCurr(e.debit) : '-'}</td>
          <td style="color: red; font-weight: bold;">${e.credit > 0 ? formatCurr(e.credit) : '-'}</td>
          <td>${e.statement}</td>
        </tr>
      `
      )
      .join('');

    const cleanHtml = `
      <div class="header">
        <div>
          <h1 style="margin: 0; font-size: 20px;">${settings.shopName}</h1>
          <p style="margin: 3px 0;">كشف حساب تاجر / مورد تفصيلي معتمد - التاريخ: ${new Date().toISOString().split('T')[0]}</p>
        </div>
      </div>

      <div class="info-box">
        <div>
          <p style="margin: 2px 0;"><strong>التاجر / المورد:</strong> ${merchantName}</p>
        </div>
        <div style="text-align: left;">
          <p style="margin: 2px 0;"><strong>مجموع التوريدات (له):</strong> ${formatCurr(totalCredit)}</p>
          <p style="margin: 2px 0; color: green;"><strong>إجمالي المسدد له (دفعات):</strong> ${formatCurr(totalDebit)}</p>
          <p style="margin: 2px 0; font-weight: bold;">
            ${netDue > 0.001 ? `<span style="color: red;">علينا للتاجر: ${formatCurr(netDue)}</span>` : netDue < -0.001 ? `<span style="color: green;">رصيد لصالحنا عند التاجر: ${formatCurr(Math.abs(netDue))}</span>` : `<span style="color: green;">الحساب مسدد بالكامل ✓</span>`}
          </p>
        </div>
      </div>

      <table>
        <thead>
          <tr>
            <th>التاريخ والوقت</th>
            <th>نوع الحركة</th>
            <th>رقم المرجع</th>
            <th>مدين (سددنا له)</th>
            <th>دائن (استلمنا منه)</th>
            <th>البيان والتفاصيل</th>
          </tr>
        </thead>
        <tbody>
          ${rowsHtml}
        </tbody>
      </table>
    `;

    printCleanDocumentOffline(cleanHtml);
  };

  // طباعة جرد المستودع النظيف
  const handlePrintCleanInventory = () => {
    const totalCost = activeItems.reduce((s, it) => s + round2(it.stockQty * it.costPrice), 0);
    const totalSale = activeItems.reduce((s, it) => s + round2(it.stockQty * it.salePrice), 0);

    const rowsHtml = activeItems
      .map(
        (it, idx) => `
        <tr>
          <td style="text-align: center;">${idx + 1}</td>
          <td>${it.code}</td>
          <td style="font-weight: bold;">${it.name}</td>
          <td>${it.category}</td>
          <td style="font-weight: bold; text-align: center;">${it.stockQty} ${it.baseUnit}</td>
          <td>${formatCurr(it.costPrice)}</td>
          <td>${formatCurr(it.salePrice)}</td>
          <td style="font-weight: bold;">${formatCurr(round2(it.stockQty * it.costPrice))}</td>
        </tr>
      `
      )
      .join('');

    const cleanHtml = `
      <div class="header">
        <div>
          <h1 style="margin: 0; font-size: 20px;">${settings.shopName}</h1>
          <p style="margin: 3px 0;">تقرير جرد المستودع والمخزون الكامل - التاريخ: ${new Date().toISOString().split('T')[0]}</p>
        </div>
        <div style="text-align: left; font-size: 11px;">
          <p style="margin: 2px 0;"><strong>رأس مال المخزون (بالتكلفة):</strong> ${formatCurr(totalCost)}</p>
          <p style="margin: 2px 0; color: green;"><strong>قيمة البيع المتوقعة:</strong> ${formatCurr(totalSale)}</p>
        </div>
      </div>

      <table>
        <thead>
          <tr>
            <th>#</th>
            <th>رمز المادة</th>
            <th>اسم المادة</th>
            <th>التصنيف</th>
            <th>الرصيد المتاح</th>
            <th>سعر الشراء</th>
            <th>سعر البيع</th>
            <th>إجمالي رأس المال</th>
          </tr>
        </thead>
        <tbody>
          ${rowsHtml}
        </tbody>
      </table>
    `;

    printCleanDocumentOffline(cleanHtml);
  };

  if (!currentUser) {
    return <AlAmeenLogin onLogin={setCurrentUser} settings={settings} onUpdateSettings={updateSettings} />;
  }

  const dashboardCards = [
    { id: 'sale_inv', name: 'فاتورة مبيعات', icon: SvgIcons.Cart, bg: 'bg-[#0097a7] hover:bg-[#00838f]' },
    { id: 'pur_inv', name: 'فاتورة مشتريات وتجار', icon: SvgIcons.Package, bg: 'bg-[#5e35b1] hover:bg-[#512da8]' },
    { id: 'unpaid_debts', name: 'الدين غير المقبوض (زبائن)', icon: SvgIcons.Debts, bg: 'bg-[#e53935] hover:bg-[#d32f2f]' },
    { id: 'merchant_debts', name: 'ديون التجار (الموردين)', icon: SvgIcons.Truck, bg: 'bg-[#0288d1] hover:bg-[#0277bd]' },
    { id: 'merchant_statement', name: 'كشف حساب تاجر', icon: SvgIcons.MerchantStatement, bg: 'bg-[#00897b] hover:bg-[#00796b]' },
    { id: 'expenses', name: 'المصاريف اليومية', icon: SvgIcons.MoneyBag, bg: 'bg-[#43a047] hover:bg-[#388e3c]' },
    { id: 'returns', name: 'بضاعة مرتجعة', icon: SvgIcons.Returns, bg: 'bg-[#f4511e] hover:bg-[#e64a19]' },
    { id: 'items', name: 'المستودع والمواد', icon: SvgIcons.Layers, bg: 'bg-[#1e88e5] hover:bg-[#1976d2]' },
    { id: 'archive', name: 'أرشيف الفواتير المعتمد', icon: SvgIcons.Printer, bg: 'bg-[#fb8c00] hover:bg-[#f57c00]' },
    { id: 'profits', name: 'المبيعات والأرباح', icon: SvgIcons.Trending, bg: 'bg-[#7b1fa2] hover:bg-[#6a1b9a]' },
    { id: 'statement', name: 'كشف حساب زبون', icon: SvgIcons.Users, bg: 'bg-[#f06292] hover:bg-[#e91e63]' },
    { id: 'settings', name: 'الإعدادات والأمان والنسخ', icon: SvgIcons.Settings, bg: 'bg-[#3949ab] hover:bg-[#303f9f]' }
  ];

  return (
    <div className={`min-h-screen bg-[#f1f5f9] text-slate-800 flex flex-col font-sans select-none text-right ${fontSizeClass}`} dir="rtl">
      {/* الشريط العلوي */}
      <header className="bg-white border-b border-slate-200 px-6 py-3 flex items-center justify-between shadow-sm sticky top-0 z-30">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-[#0097a7] rounded-xl flex items-center justify-center text-white font-bold text-xl shadow-md">
            🏛️
          </div>
          <div>
            <h1 className="font-extrabold text-slate-900 text-base">{settings.shopName}</h1>
            <span className="text-xs text-[#0097a7] font-bold">برنامج الأمين للمحاسبة والمستودعات - Enterprise Edition</span>
          </div>
        </div>

        <div className="flex items-center gap-4 text-xs font-bold">
          {lowOrOutItems.length > 0 && (
            <div
              onClick={() => setActiveTab('items')}
              className="bg-rose-50 text-rose-600 border border-rose-200 px-3 py-1.5 rounded-lg flex items-center gap-1.5 cursor-pointer shadow-sm animate-bounce"
            >
              ⚠️ {lowOrOutItems.length} مواد بها نفاذ أو قاربت على النفاذ!
            </div>
          )}
          <span className="bg-slate-100 text-slate-700 border border-slate-200 px-3 py-1.5 rounded-lg font-mono">
            1 $ = {settings.usdRate} ل.س
          </span>
          <span className="text-slate-600">{currentUser} (المدير العام)</span>
          <button
            onClick={() => setCurrentUser(null)}
            className="text-rose-600 hover:text-rose-700 bg-rose-50 px-3 py-1.5 rounded-lg border border-rose-100"
          >
            خروج 🚪
          </button>
        </div>
      </header>

      {/* 2. شبكة البطاقات الملونة (Metro Cards Grid) */}
      <div className="bg-white border-b border-slate-200 p-3 shadow-inner">
        <div className="max-w-7xl mx-auto grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-2.5">
          {dashboardCards.map(card => {
            const Icon = card.icon;
            const active = activeTab === card.id;
            return (
              <button
                key={card.id}
                onClick={() => setActiveTab(card.id as any)}
                className={`${card.bg} text-white p-2.5 rounded-xl flex flex-col items-center justify-center gap-1.5 transition-all duration-150 transform hover:-translate-y-0.5 shadow-md ${
                  active ? 'ring-4 ring-slate-800 scale-[1.02] shadow-xl' : 'opacity-95'
                }`}
              >
                <div className="p-0.5">
                  <Icon />
                </div>
                <span className="text-xs font-bold tracking-tight text-center leading-tight">
                  {card.name}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* 3. شاشات العمل */}
      <main className="flex-1 p-5 overflow-y-auto max-w-7xl w-full mx-auto">
        {activeTab === 'sale_inv' && (
          <SaleInvoiceWorkspace
            items={activeItems}
            settings={settings}
            onPostInvoice={(inv, updatedItems) => {
              updateInvoices([inv, ...invoices]);
              updateItems(updatedItems);
              printCleanA4InvoiceOffline(inv);
            }}
          />
        )}

        {activeTab === 'pur_inv' && (
          <PurchaseInvoiceWorkspace
            items={activeItems}
            settings={settings}
            onPostPurchase={(inv, updatedItems) => {
              updateInvoices([inv, ...invoices]);
              updateItems(updatedItems);
              printCleanA4InvoiceOffline(inv);
            }}
          />
        )}

        {activeTab === 'unpaid_debts' && (
          <UnpaidDebtsWorkspace
            invoices={invoices}
            items={activeItems}
            onRequestAuth={requestAdminAuth}
            onUpdateInvoiceAndItems={(updatedInv, updatedItems, newPayment) => {
              const newInvs = invoices.map(i => (i.id === updatedInv.id ? updatedInv : i));
              updateInvoices(newInvs);
              updateItems(updatedItems);
              if (newPayment) updatePayments([newPayment, ...payments]);
            }}
          />
        )}

        {activeTab === 'merchant_debts' && (
          <MerchantDebtsWorkspace
            invoices={invoices}
            onPayMerchantDebt={(invId, amount, notes, merchantName) => {
              const now = new Date();
              const paymentRec: PaymentRecord = {
                id: `PAY-${Date.now()}`,
                date: now.toISOString().split('T')[0],
                time: now.toLocaleTimeString('ar-SY', { hour: '2-digit', minute: '2-digit' }),
                amount,
                notes: notes || 'تسديد دفعة للتاجر',
                partyName: merchantName,
                partyType: 'merchant',
                invNumber: invoices.find(i => i.id === invId)?.invNumber || ''
              };

              const updated = invoices.map(inv => {
                if (inv.id === invId) {
                  const newPaid = round2(inv.paidAmount + amount);
                  const newRem = Math.max(0, round2(inv.grandTotal - newPaid));
                  return { ...inv, paidAmount: newPaid, remainingAmount: newRem };
                }
                return inv;
              });

              updateInvoices(updated);
              updatePayments([paymentRec, ...payments]);
            }}
          />
        )}

        {activeTab === 'merchant_statement' && (
          <MerchantStatementWorkspace
            invoices={invoices}
            payments={payments}
            onRequestAuth={requestAdminAuth}
            onDeletePayment={paymentId => {
              const paymentToDelete = payments.find(p => p.id === paymentId);
              if (!paymentToDelete) return;

              // إلغاء أثر الدفعة على الفاتورة ذات الصلة
              const targetInv = invoices.find(i => i.invNumber === paymentToDelete.invNumber);
              if (targetInv) {
                const newPaid = Math.max(0, round2(targetInv.paidAmount - paymentToDelete.amount));
                const newRem = Math.max(0, round2(targetInv.grandTotal - newPaid));
                const updatedInvs = invoices.map(i => (i.id === targetInv.id ? { ...i, paidAmount: newPaid, remainingAmount: newRem } : i));
                updateInvoices(updatedInvs);
              }

              updatePayments(payments.filter(p => p.id !== paymentId));
              alert('تم حذف الدفعة وإعادة الرصيد إلى ذمة التاجر بنجاح!');
            }}
            onEditPayment={(paymentId, newAmount, newNotes) => {
              const oldPayment = payments.find(p => p.id === paymentId);
              if (!oldPayment) return;

              const delta = round2(newAmount - oldPayment.amount);
              const targetInv = invoices.find(i => i.invNumber === oldPayment.invNumber);

              if (targetInv) {
                const newPaid = Math.max(0, round2(targetInv.paidAmount + delta));
                const newRem = Math.max(0, round2(targetInv.grandTotal - newPaid));
                const updatedInvs = invoices.map(i => (i.id === targetInv.id ? { ...i, paidAmount: newPaid, remainingAmount: newRem } : i));
                updateInvoices(updatedInvs);
              }

              const updatedPayments = payments.map(p => (p.id === paymentId ? { ...p, amount: newAmount, notes: newNotes } : p));
              updatePayments(updatedPayments);
              alert('تم تعديل الدفعة وتحديث الرصيد بنجاح!');
            }}
            onPrintStatement={handlePrintMerchantStatement}
          />
        )}

        {activeTab === 'expenses' && (
          <DailyExpensesWorkspace
            expenses={expenses}
            onRequestAuth={requestAdminAuth}
            onAddExpense={newExp => updateExpenses([newExp, ...expenses])}
            onDeleteExpense={id => updateExpenses(expenses.filter(e => e.id !== id))}
          />
        )}

        {activeTab === 'returns' && (
          <ReturnsWorkspace
            invoices={invoices}
            items={items}
            onProcessReturn={(retInv, updatedOrigInv, updatedItems) => {
              const newInvs = invoices.map(i => (i.id === updatedOrigInv.id ? updatedOrigInv : i));
              updateInvoices([retInv, ...newInvs]);
              updateItems(updatedItems);
              printCleanA4InvoiceOffline(retInv);
            }}
          />
        )}

        {activeTab === 'items' && (
          <ItemsManagementWorkspace
            items={activeItems}
            onRequestAuth={requestAdminAuth}
            onSaveItem={newItem => {
              const existingIdx = items.findIndex(
                it => !it.isDeleted &&
                      (it.code.trim().toLowerCase() === newItem.code.trim().toLowerCase() ||
                       it.name.trim().toLowerCase() === newItem.name.trim().toLowerCase())
              );
              if (existingIdx !== -1) {
                const confirmed = window.confirm(
                  `المادة (${newItem.name}) مسجلة مسبقاً بنفس الكود أو الاسم!\nهل ترغب في تحديث كميتها وسعرها بدلاً من إنشاء سجل مكرر؟`
                );
                if (confirmed) {
                  const updated = [...items];
                  updated[existingIdx] = {
                    ...updated[existingIdx],
                    stockQty: round2(updated[existingIdx].stockQty + newItem.stockQty),
                    salePrice: newItem.salePrice,
                    costPrice: newItem.costPrice,
                    minStock: newItem.minStock
                  };
                  updateItems(updated);
                  alert('تم تحديث رصيد وسعر المادة بنجاح دون أي تكرار!');
                }
                return;
              }
              updateItems([...items, newItem]);
            }}
            onUpdateItem={updatedItem => {
              const updated = items.map(it => (it.id === updatedItem.id ? updatedItem : it));
              updateItems(updated);
              alert('تم تعديل بيانات المادة بنجاح!');
            }}
            onDeleteItem={itemId => {
              const updated = items.map(it => (it.id === itemId ? { ...it, isDeleted: true } : it));
              updateItems(updated);
              alert('تم حذف المادة بنجاح مع الحفاظ على سلامة الفواتير السابقة!');
            }}
            onPrintInventory={handlePrintCleanInventory}
          />
        )}

        {activeTab === 'archive' && (
          <InvoiceArchiveWorkspace
            invoices={invoices}
            onRequestAuth={requestAdminAuth}
            onDeleteInvoice={invId => {
              const inv = invoices.find(i => i.id === invId);
              if (!inv) return;

              // عكس أثر المخزون عند حذف الفاتورة
              const updatedItems = items.map(item => {
                const matched = inv.rows.find(r => r.itemId === item.id);
                if (matched) {
                  const delta = matched.quantity * matched.factor;
                  const newQty = inv.type === 'sale' ? item.stockQty + delta : Math.max(0, item.stockQty - delta);
                  return { ...item, stockQty: round2(newQty) };
                }
                return item;
              });

              updateItems(updatedItems);
              updateInvoices(invoices.filter(i => i.id !== invId));
              updatePayments(payments.filter(p => p.invNumber !== inv.invNumber));
              alert('تم حذف الفاتورة وإلغاء أثرها المالي والمخزني بنجاح!');
            }}
            onPrintA4={printCleanA4InvoiceOffline}
            onPrintFilteredArchive={(filteredList, filterName) => {
              const rowsHtml = filteredList
                .map(
                  (inv, i) => `
                  <tr>
                    <td style="text-align:center;">${i + 1}</td>
                    <td>${inv.invNumber}</td>
                    <td style="font-weight:bold;">${inv.type === 'sale' ? 'مبيعات' : inv.type === 'purchase' ? 'مشتريات' : 'مرتجع'}</td>
                    <td>${inv.customerName}</td>
                    <td>${inv.invDate} ${inv.invTime}</td>
                    <td style="font-weight:bold;">${formatCurr(inv.grandTotal, inv.currency)}</td>
                    <td style="color:red;">${formatCurr(inv.remainingAmount, inv.currency)}</td>
                  </tr>
                `
                )
                .join('');

              const cleanHtml = `
                <div class="header">
                  <div>
                    <h1 style="margin: 0; font-size: 20px;">${settings.shopName}</h1>
                    <p style="margin: 3px 0;">أرشيف الفواتير المعتمد (${filterName}) - التاريخ: ${new Date().toISOString().split('T')[0]}</p>
                  </div>
                </div>

                <table>
                  <thead>
                    <tr>
                      <th>#</th>
                      <th>رقم الفاتورة</th>
                      <th>نوع الفاتورة</th>
                      <th>الطرف (السيد: / التاجر)</th>
                      <th>التاريخ والوقت</th>
                      <th>الإجمالي</th>
                      <th>المتبقي دين</th>
                    </tr>
                  </thead>
                  <tbody>
                    ${rowsHtml}
                  </tbody>
                </table>
              `;

              printCleanDocumentOffline(cleanHtml);
            }}
          />
        )}

        {activeTab === 'profits' && (
          <ProfitsReportWorkspace invoices={invoices} expenses={expenses} />
        )}

        {activeTab === 'statement' && (
          <StatementWorkspace
            invoices={invoices}
            payments={payments}
            onPrintStatement={handlePrintCustomerStatement}
          />
        )}

        {activeTab === 'settings' && (
          <SettingsWorkspace
            settings={settings}
            allAppData={{ items, invoices, payments, expenses, settings }}
            onSaveSettings={updateSettings}
            onRestoreFullData={(restored) => {
              if (restored.items) updateItems(restored.items);
              if (restored.invoices) updateInvoices(restored.invoices);
              if (restored.expenses) updateExpenses(restored.expenses);
              if (restored.payments) updatePayments(restored.payments);
              if (restored.settings) updateSettings(restored.settings);
              alert('تمت استعادة النسخة الاحتياطية بنجاح ومطابقتها 100%!');
            }}
          />
        )}
      </main>

      {/* نافذة التحقق الأمني بكلمة مرور المدير لتنفيذ أي حذف أو تعديل مالي */}
      {securityModal.isOpen && (
        <div className="fixed inset-0 bg-slate-900/70 backdrop-blur-sm flex items-center justify-center p-4 z-50">
          <form onSubmit={handleVerifyAdminPass} className="bg-white rounded-2xl w-full max-w-sm p-6 space-y-4 shadow-2xl border border-rose-300">
            <div className="text-center">
              <span className="text-3xl">🔐</span>
              <h4 className="font-bold text-rose-600 text-base mt-1">{securityModal.title}</h4>
              <p className="text-slate-600 text-xs mt-1">{securityModal.description}</p>
            </div>
            <div>
              <label className="text-slate-700 block mb-1 font-bold">كلمة مرور المدير:</label>
              <input
                type="password"
                required
                placeholder="أدخل كلمة المرور..."
                value={inputPass}
                onChange={e => setInputPass(e.target.value)}
                className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2 text-slate-900 font-bold"
                autoFocus
              />
            </div>
            <div className="flex justify-end gap-2 pt-2 border-t">
              <button
                type="button"
                onClick={() => setSecurityModal({ isOpen: false, title: '', description: '', onSuccess: () => {} })}
                className="px-4 py-1.5 bg-slate-100 text-slate-700 rounded-lg font-bold"
              >
                إلغاء
              </button>
              <button
                type="submit"
                className="px-5 py-1.5 bg-rose-600 hover:bg-rose-700 text-white font-bold rounded-lg shadow-sm"
              >
                تأكيد العملية
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
}

// ==========================================
// 4. فاتورة المبيعات
// ==========================================
function SaleInvoiceWorkspace({
  items,
  settings,
  onPostInvoice
}: {
  items: AlAmeenItem[];
  settings: AlAmeenSettings;
  onPostInvoice: (inv: AlAmeenInvoice, updatedItems: AlAmeenItem[]) => void;
}) {
  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [currency, setCurrency] = useState<'USD' | 'SYP'>('USD');
  const [discountStr, setDiscountStr] = useState('0');
  const [paidStr, setPaidStr] = useState('0');
  const [notes, setNotes] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const currentDate = new Date().toISOString().split('T')[0];
  const currentTime = new Date().toLocaleTimeString('ar-SY', { hour: '2-digit', minute: '2-digit' });

  const [rows, setRows] = useState<InvoiceRow[]>([]);
  const [searchCode, setSearchCode] = useState('');

  const discount = parseDecimal(discountStr);
  const subTotal = round2(rows.reduce((s, r) => s + r.total, 0));
  const grandTotal = Math.max(0, round2(subTotal - discount));
  const paid = parseDecimal(paidStr);
  const remaining = Math.max(0, round2(grandTotal - paid));

  useEffect(() => {
    setPaidStr(String(grandTotal));
  }, [grandTotal]);

  const addRow = (it: AlAmeenItem) => {
    if (it.stockQty <= 0) {
      alert(`عذراً، المادة (${it.name}) غير متوفرة في المستودع حالياً (تم نفاذ الكمية)! لا يمكن إكمال الفاتورة.`);
      return;
    }

    setRows([
      ...rows,
      {
        itemId: it.id,
        itemCode: it.code,
        itemName: it.name,
        unit: it.baseUnit,
        factor: 1,
        quantity: 1,
        price: it.salePrice,
        total: it.salePrice,
        cost: it.costPrice,
        addedAt: `${currentDate} ${currentTime}`
      }
    ]);
    setSearchCode('');
  };

  const updateRow = (index: number, field: keyof InvoiceRow, val: any) => {
    const list = [...rows];
    const r = { ...list[index] };
    const it = items.find(i => i.id === r.itemId);

    if (field === 'quantity') {
      const q = parseDecimal(val);
      if (it && q * r.factor > it.stockQty) {
        alert(`الكمية المطلوبة (${q} ${r.unit}) تتجاوز الرصيد المتوفر في المستودع (${it.stockQty} ${it.baseUnit})!`);
        return;
      }
      r.quantity = q;
      r.total = round2(r.quantity * r.price);
    } else if (field === 'price') {
      r.price = parseDecimal(val);
      r.total = round2(r.quantity * r.price);
    } else if (field === 'unit') {
      r.unit = val;
      if (it && it.subUnitName === val) {
        r.factor = it.subUnitFactor || 1;
        r.price = it.subUnitPrice || (it.salePrice * r.factor);
      } else if (it) {
        r.factor = 1;
        r.price = it.salePrice;
      }
      r.total = round2(r.quantity * r.price);
    }

    list[index] = r;
    setRows(list);
  };

  const postInvoice = () => {
    if (isSubmitting) return;
    if (rows.length === 0) {
      alert('الفاتورة فارغة، يرجى إضافة مواد للبيع أولاً!');
      return;
    }
    if (!customerName.trim()) {
      alert('يرجى كتابة اسم الزبون (السيد:) أولاً!');
      return;
    }

    for (const r of rows) {
      const it = items.find(i => i.id === r.itemId);
      const reqQty = r.quantity * r.factor;
      if (!it || it.stockQty < reqQty) {
        alert(`لا يمكن إكمال الفاتورة! رصيد المادة (${r.itemName}) المتاح في المستودع هو (${it ? it.stockQty : 0}) وهو أقل من الكمية المطلوبة.`);
        return;
      }
    }

    setIsSubmitting(true);
    const invNumber = `SAL-${Date.now().toString().slice(-6)}`;

    const updatedItems = items.map(it => {
      const matched = rows.find(r => r.itemId === it.id);
      if (matched) {
        const delta = matched.quantity * matched.factor;
        return { ...it, stockQty: round2(Math.max(0, it.stockQty - delta)) };
      }
      return it;
    });

    const newInv: AlAmeenInvoice = {
      id: Date.now(),
      invNumber,
      type: 'sale',
      customerName: customerName.trim(),
      customerPhone: customerPhone.trim() || 'لا يوجد',
      rows,
      subTotal,
      discount,
      grandTotal,
      initialPaid: paid,
      paidAmount: paid,
      remainingAmount: remaining,
      currency,
      exchangeRate: settings.usdRate,
      invDate: currentDate,
      invTime: currentTime,
      notes: notes.trim()
    };

    onPostInvoice(newInv, updatedItems);
    setRows([]);
    setCustomerName('');
    setCustomerPhone('');
    setNotes('');
    setIsSubmitting(false);
  };

  const filteredItems = searchCode.trim()
    ? items.filter(i => i.code.includes(searchCode) || i.name.toLowerCase().includes(searchCode.toLowerCase())).slice(0, 5)
    : [];

  return (
    <div className="bg-white border border-slate-200 rounded-2xl p-6 space-y-4 shadow-sm">
      <div className="flex items-center justify-between border-b pb-3">
        <h2 className="text-base font-bold text-slate-800 flex items-center gap-2">
          <span className="w-3 h-3 bg-[#0097a7] rounded-full inline-block"></span>
          فاتورة مبيعات جديدة (تبدأ فارغة - لا خصم تلقائي)
        </h2>
        <div className="flex items-center gap-3 text-xs">
          <span className="text-slate-500 font-bold">العملة:</span>
          <select value={currency} onChange={e => setCurrency(e.target.value as any)} className="bg-slate-50 border border-slate-300 rounded px-3 py-1 font-bold text-slate-800">
            <option value="USD">دولار أمريكي ($ USD)</option>
            <option value="SYP">ليرة سورية (ل.س SYP)</option>
          </select>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-3 bg-slate-50 p-4 rounded-xl border border-slate-200 text-xs">
        <div>
          <label className="text-slate-600 block mb-1 font-bold">السيد (الزبون):</label>
          <input
            type="text"
            required
            placeholder="اسم الزبون..."
            value={customerName}
            onChange={e => setCustomerName(e.target.value)}
            className="w-full bg-white border border-slate-300 rounded-lg p-2 text-slate-800 font-bold"
          />
        </div>

        <div>
          <label className="text-slate-600 block mb-1 font-bold">رقم الجوال:</label>
          <input
            type="text"
            placeholder="0912345678"
            value={customerPhone}
            onChange={e => setCustomerPhone(e.target.value)}
            className="w-full bg-white border border-slate-300 rounded-lg p-2 text-slate-800"
          />
        </div>

        <div>
          <label className="text-slate-600 block mb-1 font-bold">تاريخ ووقت الفاتورة:</label>
          <div className="bg-white border border-slate-300 rounded-lg p-2 text-[#0097a7] font-mono font-bold">
            {currentDate} | {currentTime}
          </div>
        </div>

        <div className="relative">
          <label className="text-[#0097a7] block mb-1 font-bold">+ إضافة مادة للفاتورة:</label>
          <input
            type="text"
            placeholder="ابحث بالكود أو الاسم..."
            value={searchCode}
            onChange={e => setSearchCode(e.target.value)}
            className="w-full bg-white border border-[#0097a7] rounded-lg p-2 text-slate-800 focus:outline-none"
          />
          {filteredItems.length > 0 && (
            <div className="absolute top-full right-0 left-0 mt-1 bg-white border border-slate-200 rounded-xl shadow-2xl z-30 divide-y divide-slate-100">
              {filteredItems.map(it => (
                <div key={it.id} onClick={() => addRow(it)} className="p-3 hover:bg-slate-50 cursor-pointer flex justify-between items-center text-xs">
                  <div>
                    <span className="font-bold text-slate-900 block">{it.code} - {it.name}</span>
                    <span className={`text-[11px] font-bold ${it.stockQty <= 0 ? 'text-rose-600' : 'text-slate-500'}`}>
                      {it.stockQty <= 0 ? '⛔ تم نفاذ الكمية (0)' : `المتوفر: ${it.stockQty} ${it.baseUnit}`}
                    </span>
                  </div>
                  <span className="text-[#0097a7] font-mono font-bold">{formatCurr(it.salePrice, currency)}</span>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      <div className="border border-slate-200 rounded-xl overflow-x-auto bg-white shadow-sm">
        <table className="w-full text-right text-xs">
          <thead className="bg-slate-50 text-slate-700 font-bold border-b border-slate-200">
            <tr>
              <th className="p-3">#</th>
              <th className="p-3">رمز المادة</th>
              <th className="p-3">اسم المادة والمواصفات</th>
              <th className="p-3">الوحدة</th>
              <th className="p-3">الكمية</th>
              <th className="p-3">السعر الإفرادي</th>
              <th className="p-3">الإجمالي</th>
              <th className="p-3 text-center">حذف</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 text-slate-800 font-mono">
            {rows.length === 0 ? (
              <tr>
                <td colSpan={8} className="p-8 text-center text-slate-400 font-sans">
                  الفاتورة فارغة حالياً. ابحث عن مادة من الصندوق بالأعلى لإضافتها.
                </td>
              </tr>
            ) : (
              rows.map((r, idx) => {
                const it = items.find(i => i.id === r.itemId);
                return (
                  <tr key={idx} className="hover:bg-slate-50">
                    <td className="p-3 text-slate-400">{idx + 1}</td>
                    <td className="p-3 font-bold text-[#0097a7]">{r.itemCode}</td>
                    <td className="p-3 font-sans font-bold text-slate-900">{r.itemName}</td>
                    <td className="p-3 font-sans">
                      <select
                        value={r.unit}
                        onChange={e => updateRow(idx, 'unit', e.target.value)}
                        className="bg-slate-50 border border-slate-200 rounded px-2 py-1 text-xs"
                      >
                        <option value={it?.baseUnit}>{it?.baseUnit}</option>
                        {it?.subUnitName && (
                          <option value={it.subUnitName}>{it.subUnitName} ({it.subUnitFactor} {it.baseUnit})</option>
                        )}
                      </select>
                    </td>
                    <td className="p-3">
                      <input
                        type="text"
                        value={r.quantity}
                        onChange={e => updateRow(idx, 'quantity', e.target.value)}
                        className="w-20 bg-slate-50 border border-slate-300 rounded p-1 text-center font-bold"
                      />
                    </td>
                    <td className="p-3">
                      <input
                        type="text"
                        value={r.price}
                        onChange={e => updateRow(idx, 'price', e.target.value)}
                        className="w-24 bg-slate-50 border border-slate-300 rounded p-1 font-bold text-[#0097a7]"
                      />
                    </td>
                    <td className="p-3 font-bold text-slate-900">{formatCurr(r.total, currency)}</td>
                    <td className="p-3 text-center font-sans">
                      <button onClick={() => setRows(rows.filter((_, i) => i !== idx))} className="text-rose-500 font-bold">✕</button>
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>

      <div className="bg-slate-50 p-3 rounded-xl border border-slate-200">
        <label className="text-slate-700 block mb-1 font-bold">ملاحظات الفاتورة (اختيارية):</label>
        <textarea
          rows={2}
          placeholder="تم الاتفاق على تسديد المبلغ الأسبوع القادم، تم تسليم جزء من المواد، شروط خاصة..."
          value={notes}
          onChange={e => setNotes(e.target.value)}
          className="w-full bg-white border border-slate-300 rounded p-2 text-slate-800 text-xs"
        />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 bg-slate-50 p-4 rounded-xl border border-slate-200 text-xs">
        <div>
          <span className="text-slate-500 block mb-1 font-bold">المجموع:</span>
          <span className="text-base font-bold font-mono text-slate-900">{formatCurr(subTotal, currency)}</span>
        </div>
        <div>
          <span className="text-slate-500 block mb-1 font-bold">الخصم:</span>
          <input
            type="text"
            value={discountStr}
            onChange={e => setDiscountStr(e.target.value)}
            className="w-full bg-white border border-slate-300 rounded p-1.5 font-mono"
          />
        </div>
        <div>
          <span className="text-[#0097a7] font-bold block mb-1">الصافي النهائي:</span>
          <span className="text-lg font-bold font-mono text-[#0097a7]">{formatCurr(grandTotal, currency)}</span>
        </div>
        <div>
          <span className="text-slate-500 block mb-1 font-bold">المدفوع نقداً:</span>
          <input
            type="text"
            value={paidStr}
            onChange={e => setPaidStr(e.target.value)}
            className="w-full bg-white border border-slate-300 rounded p-1.5 text-emerald-600 font-bold font-mono"
          />
        </div>
      </div>

      {remaining > 0 && (
        <div className="p-3 bg-amber-50 border border-amber-200 text-amber-800 rounded-xl text-xs flex justify-between items-center font-bold">
          <span>المتبقي ذمة سيتم ترحيلها لتبويب (الدين غير المقبوض):</span>
          <span className="font-mono text-base">{formatCurr(remaining, currency)}</span>
        </div>
      )}

      <div className="flex justify-end gap-2 pt-2">
        <button
          onClick={postInvoice}
          disabled={rows.length === 0 || isSubmitting}
          className="px-6 py-2.5 bg-[#0097a7] hover:bg-[#00838f] disabled:opacity-50 text-white text-xs font-bold rounded-xl shadow-md transition-colors"
        >
          {isSubmitting ? 'جارٍ الترحيل والطباعة...' : '✓ حفظ الفاتورة وإنقاص المستودع والطباعة التلقائية A4'}
        </button>
      </div>
    </div>
  );
}

// ==========================================
// 5. فاتورة المشتريات والتجار
// ==========================================
function PurchaseInvoiceWorkspace({
  items,
  settings,
  onPostPurchase
}: {
  items: AlAmeenItem[];
  settings: AlAmeenSettings;
  onPostPurchase: (inv: AlAmeenInvoice, updatedItems: AlAmeenItem[]) => void;
}) {
  const [merchantName, setMerchantName] = useState('');
  const [shopName, setShopName] = useState('');
  const [currency, setCurrency] = useState<'USD' | 'SYP'>('USD');
  const [paidStr, setPaidStr] = useState('0');
  const [notes, setNotes] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const [rows, setRows] = useState<InvoiceRow[]>([]);
  const [selectedItemId, setSelectedItemId] = useState<number>(items[0]?.id || 1);
  const [qtyStr, setQtyStr] = useState('1');
  const [costStr, setCostStr] = useState('0');

  const subTotal = round2(rows.reduce((s, r) => s + r.total, 0));
  const paid = parseDecimal(paidStr);

  const addPurchaseRow = () => {
    const it = items.find(i => i.id === selectedItemId);
    const q = parseDecimal(qtyStr);
    const c = parseDecimal(costStr) || (it ? it.costPrice : 0);
    if (!it || q <= 0) return;

    setRows([
      ...rows,
      {
        itemId: it.id,
        itemCode: it.code,
        itemName: it.name,
        unit: it.baseUnit,
        factor: 1,
        quantity: q,
        price: c,
        total: round2(q * c),
        cost: c
      }
    ]);
    setQtyStr('1');
  };

  const savePurchase = () => {
    if (isSubmitting) return;
    if (rows.length === 0 || !merchantName.trim()) {
      alert('يرجى كتابة اسم التاجر وإضافة مواد للفاتورة!');
      return;
    }

    setIsSubmitting(true);
    const invNumber = `PUR-${Date.now().toString().slice(-6)}`;
    const remaining = Math.max(0, round2(subTotal - paid));

    const updatedItems = items.map(it => {
      const matched = rows.find(r => r.itemId === it.id);
      if (matched) {
        return { ...it, stockQty: round2(it.stockQty + matched.quantity), costPrice: matched.price };
      }
      return it;
    });

    const inv: AlAmeenInvoice = {
      id: Date.now(),
      invNumber,
      type: 'purchase',
      customerName: merchantName.trim(),
      customerPhone: '',
      merchantName: merchantName.trim(),
      shopName: shopName.trim() || settings.shopName,
      rows,
      subTotal,
      discount: 0,
      grandTotal: subTotal,
      initialPaid: paid,
      paidAmount: paid,
      remainingAmount: remaining,
      currency,
      exchangeRate: settings.usdRate,
      invDate: new Date().toISOString().split('T')[0],
      invTime: new Date().toLocaleTimeString('ar-SY', { hour: '2-digit', minute: '2-digit' }),
      notes: notes.trim()
    };

    onPostPurchase(inv, updatedItems);
    setRows([]);
    setMerchantName('');
    setNotes('');
    setIsSubmitting(false);
    alert(
      remaining > 0
        ? `تم ترحيل المواد للمستودع، وترحيل باقي حساب التاجر (${formatCurr(remaining, currency)}) إلى تبويب (ديون التجار)!`
        : `تم حفظ فاتورة المشتريات بالكامل وزيادة رصيد المستودع!`
    );
  };

  return (
    <div className="bg-white border border-slate-200 rounded-2xl p-6 space-y-4 shadow-sm text-xs">
      <h3 className="font-bold text-sm text-slate-800 flex items-center gap-2 border-b pb-3">
        <span className="w-3 h-3 bg-[#5e35b1] rounded-full inline-block"></span>
        فاتورة مشتريات وتوريد بضاعة من تاجر
      </h3>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-3 bg-slate-50 p-4 rounded-xl border border-slate-200">
        <div>
          <label className="text-slate-700 block mb-1 font-bold">اسم التاجر / المورد:</label>
          <input
            type="text"
            required
            placeholder="التاجر أبو أحمد، معمل الشام..."
            value={merchantName}
            onChange={e => setMerchantName(e.target.value)}
            className="w-full bg-white border border-slate-300 rounded-lg p-2 text-slate-900 font-bold"
          />
        </div>

        <div>
          <label className="text-slate-700 block mb-1">اسم المعمل أو المحل:</label>
          <input
            type="text"
            placeholder="شركة الكابلات الحديثة..."
            value={shopName}
            onChange={e => setShopName(e.target.value)}
            className="w-full bg-white border border-slate-300 rounded-lg p-2 text-slate-900"
          />
        </div>

        <div>
          <label className="text-slate-700 block mb-1">العملة:</label>
          <select value={currency} onChange={e => setCurrency(e.target.value as any)} className="w-full bg-white border border-slate-300 rounded-lg p-2 font-bold text-slate-900">
            <option value="USD">دولار أمريكي ($ USD)</option>
            <option value="SYP">ليرة سورية (ل.س SYP)</option>
          </select>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-2 bg-slate-50 p-3 rounded-xl border border-slate-200 items-end">
        <div>
          <label className="text-slate-700 block mb-1">الصنف المستلم:</label>
          <select
            value={selectedItemId}
            onChange={e => {
              const id = Number(e.target.value);
              setSelectedItemId(id);
              const it = items.find(i => i.id === id);
              if (it) setCostStr(String(it.costPrice));
            }}
            className="w-full bg-white border border-slate-300 rounded p-1.5 text-slate-800"
          >
            {items.map(i => (
              <option key={i.id} value={i.id}>{i.code} - {i.name}</option>
            ))}
          </select>
        </div>

        <div>
          <label className="text-slate-700 block mb-1">عدد الصنف (الكمية):</label>
          <input type="text" value={qtyStr} onChange={e => setQtyStr(e.target.value)} className="w-full bg-white border border-slate-300 rounded p-1.5 font-bold" />
        </div>

        <div>
          <label className="text-slate-700 block mb-1">سعر الشراء للوحدة:</label>
          <input type="text" value={costStr} onChange={e => setCostStr(e.target.value)} className="w-full bg-white border border-slate-300 rounded p-1.5 font-bold" />
        </div>

        <button onClick={addPurchaseRow} className="bg-[#5e35b1] hover:bg-[#512da8] text-white font-bold py-2 rounded shadow">
          + إضافة للفاتورة
        </button>
      </div>

      <div className="border border-slate-200 rounded-xl overflow-x-auto bg-white">
        <table className="w-full text-right text-xs">
          <thead className="bg-slate-50 text-slate-700 font-bold border-b">
            <tr>
              <th className="p-3">#</th>
              <th className="p-3">اسم الصنف</th>
              <th className="p-3">العدد (الكمية)</th>
              <th className="p-3">سعر الشراء للوحدة</th>
              <th className="p-3">الإجمالي</th>
              <th className="p-3 text-center">حذف</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 text-slate-800 font-mono">
            {rows.map((r, idx) => (
              <tr key={idx}>
                <td className="p-3 text-slate-400">{idx + 1}</td>
                <td className="p-3 font-sans font-bold text-slate-900">{r.itemName}</td>
                <td className="p-3 text-[#5e35b1] font-bold">{r.quantity} {r.unit}</td>
                <td className="p-3">{formatCurr(r.price, currency)}</td>
                <td className="p-3 font-bold text-emerald-600">{formatCurr(r.total, currency)}</td>
                <td className="p-3 text-center font-sans">
                  <button onClick={() => setRows(rows.filter((_, i) => i !== idx))} className="text-rose-500 font-bold">✕</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="bg-slate-50 p-3 rounded-xl border border-slate-200">
        <label className="text-slate-700 block mb-1 font-bold">ملاحظات فاتورة الشراء:</label>
        <textarea
          rows={2}
          placeholder="شروط التسديد للتاجر، موعد استلام بقية المواد..."
          value={notes}
          onChange={e => setNotes(e.target.value)}
          className="w-full bg-white border border-slate-300 rounded p-2 text-slate-800 text-xs"
        />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-3 bg-slate-50 p-4 rounded-xl border border-slate-200">
        <div>
          <span className="text-slate-600 block mb-1">إجمالي الفاتورة:</span>
          <span className="text-base font-bold font-mono text-slate-900">{formatCurr(subTotal, currency)}</span>
        </div>
        <div>
          <span className="text-slate-600 block mb-1">المبلغ المسدد الآن للتاجر:</span>
          <input
            type="text"
            value={paidStr}
            onChange={e => setPaidStr(e.target.value)}
            className="w-full bg-white border border-slate-300 rounded p-1.5 text-emerald-600 font-bold font-mono"
          />
        </div>
        <div>
          <span className="text-slate-600 block mb-1">المتبقي دين للتاجر:</span>
          <span className="text-base font-bold font-mono text-rose-600">{formatCurr(Math.max(0, round2(subTotal - paid)), currency)}</span>
        </div>
      </div>

      <div className="flex justify-end pt-2">
        <button
          onClick={savePurchase}
          disabled={rows.length === 0 || isSubmitting}
          className="px-6 py-2.5 bg-[#5e35b1] hover:bg-[#512da8] disabled:opacity-50 text-white font-bold rounded-xl shadow-md"
        >
          {isSubmitting ? 'جارٍ الترحيل...' : '✓ ترحيل المواد للمستودع والفاتورة للحسابات والطباعة A4'}
        </button>
      </div>
    </div>
  );
}

// ==========================================
// 6. بوابة الديون غير المقبوضة (مع منع السداد الزائد وتأكيد كلمة المرور)
// ==========================================
function UnpaidDebtsWorkspace({
  invoices,
  items,
  onRequestAuth,
  onUpdateInvoiceAndItems
}: {
  invoices: AlAmeenInvoice[];
  items: AlAmeenItem[];
  onRequestAuth: (title: string, desc: string, cb: () => void) => void;
  onUpdateInvoiceAndItems: (updatedInv: AlAmeenInvoice, updatedItems: AlAmeenItem[], paymentRecord?: PaymentRecord) => void;
}) {
  const unpaidList = useMemo(() => {
    return invoices.filter(i => i.type === 'sale' && i.remainingAmount > 0.001);
  }, [invoices]);

  const totalDebt = round2(unpaidList.reduce((s, i) => s + i.remainingAmount, 0));

  const [activeInvoice, setActiveInvoice] = useState<AlAmeenInvoice | null>(null);
  const [payAmountStr, setPayAmountStr] = useState('');
  const [payNotes, setPayNotes] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const [selectedItemId, setSelectedItemId] = useState<number>(items[0]?.id || 1);
  const [newQtyStr, setNewQtyStr] = useState('1');
  const [newPriceStr, setNewPriceStr] = useState('0');

  useEffect(() => {
    const it = items.find(i => i.id === selectedItemId);
    if (it) setNewPriceStr(String(it.salePrice));
  }, [selectedItemId]);

  const handlePayInstallment = () => {
    if (!activeInvoice || isSubmitting) return;
    const amount = parseDecimal(payAmountStr);

    if (amount <= 0) {
      alert('يرجى إدخال مبلغ صحيح لتسديد الدفعة!');
      return;
    }

    // الشرط رقم 3: منع سداد مبلغ أكبر من الدين المتبقي على الزبون قطيعاً
    if (amount > activeInvoice.remainingAmount) {
      alert(`عذراً، لا يمكن قبول هذا المبلغ!\nالمبلغ المتبقي كدين على الزبون هو (${formatCurr(activeInvoice.remainingAmount, activeInvoice.currency)}) فقط، ولا يمكن تنزيل مبلغ أكبر من الدين المستحق.`);
      return;
    }

    setIsSubmitting(true);
    const now = new Date();
    const dateStr = now.toISOString().split('T')[0];
    const timeStr = now.toLocaleTimeString('ar-SY', { hour: '2-digit', minute: '2-digit' });

    const newPaid = round2(activeInvoice.paidAmount + amount);
    const newRem = Math.max(0, round2(activeInvoice.grandTotal - newPaid));

    const paymentRec: PaymentRecord = {
      id: `CUST-PAY-${Date.now()}`,
      date: dateStr,
      time: timeStr,
      amount,
      notes: payNotes.trim() || 'تسديد دفعة دين من الزبون',
      partyName: activeInvoice.customerName,
      partyType: 'customer',
      invNumber: activeInvoice.invNumber
    };

    const updatedInv: AlAmeenInvoice = {
      ...activeInvoice,
      paidAmount: newPaid,
      remainingAmount: newRem
    };

    onUpdateInvoiceAndItems(updatedInv, items, paymentRec);
    setActiveInvoice(updatedInv);
    setPayAmountStr('');
    setPayNotes('');
    setIsSubmitting(false);
    alert('تم تسجيل الدفعة بنجاح وخصمها من رصيد دين الزبون!');
  };

  const handleAddNewItemToDebt = () => {
    if (!activeInvoice || isSubmitting) return;
    const qty = parseDecimal(newQtyStr);
    const price = parseDecimal(newPriceStr);
    if (qty <= 0) return;

    const it = items.find(i => i.id === selectedItemId);
    if (!it) return;

    if (it.stockQty < qty) {
      alert(`عذراً، الرصيد المتاح بالمستودع (${it.stockQty} ${it.baseUnit}) لا يكفي للكمية المطلوبة!`);
      return;
    }

    setIsSubmitting(true);
    const nowStr = `${new Date().toISOString().split('T')[0]} ${new Date().toLocaleTimeString('ar-SY', { hour: '2-digit', minute: '2-digit' })}`;

    const updatedItems = items.map(item => {
      if (item.id === it.id) {
        return { ...item, stockQty: round2(item.stockQty - qty) };
      }
      return item;
    });

    const itemTotal = round2(qty * (price || it.salePrice));
    const newRow: InvoiceRow = {
      itemId: it.id,
      itemCode: it.code,
      itemName: it.name,
      unit: it.baseUnit,
      factor: 1,
      quantity: qty,
      price: price || it.salePrice,
      total: itemTotal,
      cost: it.costPrice,
      addedAt: nowStr
    };

    const newRows = [...activeInvoice.rows, newRow];
    const newSub = round2(activeInvoice.subTotal + itemTotal);
    const newGrand = round2(activeInvoice.grandTotal + itemTotal);
    const newRem = round2(newGrand - activeInvoice.paidAmount);

    const updatedInv: AlAmeenInvoice = {
      ...activeInvoice,
      rows: newRows,
      subTotal: newSub,
      grandTotal: newGrand,
      remainingAmount: newRem
    };

    onUpdateInvoiceAndItems(updatedInv, updatedItems);
    setActiveInvoice(updatedInv);
    setNewQtyStr('1');
    setIsSubmitting(false);
    alert(`تم إنقاص الكمية من المستودع وتثبيت المادة في ذمة الزبون بنجاح!`);
  };

  return (
    <div className="bg-white border border-slate-200 p-6 rounded-2xl space-y-4 shadow-sm text-xs">
      <div className="flex justify-between items-center border-b pb-3">
        <div>
          <h3 className="font-bold text-sm text-slate-800 flex items-center gap-2">
            <span className="w-3 h-3 bg-[#e53935] rounded-full inline-block"></span>
            فواتير الدين غير المقبوضة ({unpaidList.length} فاتورة معلقة)
          </h3>
          <p className="text-slate-500 text-[11px]">يمكنك تسديد دفعات نقدية أو إضافة مواد جديدة يسحبها الزبون من المستودع.</p>
        </div>
        <div className="bg-rose-50 border border-rose-200 text-rose-600 px-4 py-2 rounded-xl font-bold font-mono text-sm">
          مجموع ديون الزبائن: {formatCurr(totalDebt)}
        </div>
      </div>

      <div className="border border-slate-200 rounded-xl overflow-x-auto bg-white">
        <table className="w-full text-right text-xs">
          <thead className="bg-slate-50 text-slate-700 font-bold">
            <tr>
              <th className="p-3">رقم الفاتورة</th>
              <th className="p-3">اسم الزبون المدين</th>
              <th className="p-3">رقم الجوال</th>
              <th className="p-3">تاريخ الفاتورة</th>
              <th className="p-3">إجمالي الحساب</th>
              <th className="p-3">المسدد منه</th>
              <th className="p-3">الدين المتبقي</th>
              <th className="p-3 text-center">إجراءات</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 text-slate-800 font-mono">
            {unpaidList.length === 0 ? (
              <tr>
                <td colSpan={8} className="p-8 text-center text-slate-400 font-sans">
                  لا توجد أي فواتير دين غير مقبوضة حالياً، جميع الحسابات مسددة بالكامل!
                </td>
              </tr>
            ) : (
              unpaidList.map(inv => (
                <tr key={inv.id} className="hover:bg-slate-50">
                  <td className="p-3 text-[#e53935] font-bold">{inv.invNumber}</td>
                  <td className="p-3 font-sans font-bold text-slate-900">{inv.customerName}</td>
                  <td className="p-3 text-slate-500">{inv.customerPhone}</td>
                  <td className="p-3 text-slate-500">{inv.invDate} {inv.invTime}</td>
                  <td className="p-3">{formatCurr(inv.grandTotal, inv.currency)}</td>
                  <td className="p-3 text-emerald-600">{formatCurr(inv.paidAmount, inv.currency)}</td>
                  <td className="p-3 font-bold text-rose-600">{formatCurr(inv.remainingAmount, inv.currency)}</td>
                  <td className="p-3 text-center font-sans">
                    <button
                      onClick={() => setActiveInvoice(inv)}
                      className="bg-[#e53935] hover:bg-[#d32f2f] text-white font-bold px-3 py-1.5 rounded-lg text-xs shadow-sm"
                    >
                      📂 فتح وتعديل الفاتورة
                    </button>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {activeInvoice && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4 z-50 overflow-y-auto">
          <div className="bg-white rounded-2xl w-full max-w-3xl p-6 space-y-4 shadow-2xl my-6 border border-slate-200">
            <div className="flex justify-between items-center border-b pb-3">
              <div>
                <h4 className="font-bold text-slate-900 text-base">فاتورة دين رقم #{activeInvoice.invNumber}</h4>
                <p className="text-slate-500 text-xs">الزبون: {activeInvoice.customerName} | الجوال: {activeInvoice.customerPhone}</p>
              </div>
              <button onClick={() => setActiveInvoice(null)} className="text-slate-400 hover:text-slate-700 font-bold text-lg">✕</button>
            </div>

            <div className="grid grid-cols-3 gap-3 bg-slate-50 p-4 rounded-xl border border-slate-200 text-xs font-mono text-center">
              <div><span className="text-slate-500 block font-sans">الإجمالي:</span><span className="text-slate-900 font-bold text-sm">{formatCurr(activeInvoice.grandTotal, activeInvoice.currency)}</span></div>
              <div><span className="text-slate-500 block font-sans">المسدد:</span><span className="text-emerald-600 font-bold text-sm">{formatCurr(activeInvoice.paidAmount, activeInvoice.currency)}</span></div>
              <div><span className="text-slate-500 block font-sans">المتبقي دين:</span><span className="text-rose-600 font-bold text-sm">{formatCurr(activeInvoice.remainingAmount, activeInvoice.currency)}</span></div>
            </div>

            <div className="bg-emerald-50/60 p-4 rounded-xl border border-emerald-100 space-y-2">
              <span className="text-emerald-800 font-bold block">💵 تسديد دفعة مالية من الدين (مع منع السداد الزائد):</span>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-2">
                <input
                  type="text"
                  placeholder="المبلغ المسدد..."
                  value={payAmountStr}
                  onChange={e => setPayAmountStr(e.target.value)}
                  className="bg-white border border-slate-300 rounded p-2 text-emerald-700 font-bold font-mono"
                />
                <input
                  type="text"
                  placeholder="ملاحظات الدفعة..."
                  value={payNotes}
                  onChange={e => setPayNotes(e.target.value)}
                  className="bg-white border border-slate-300 rounded p-2"
                />
                <button
                  onClick={handlePayInstallment}
                  disabled={isSubmitting}
                  className="bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white font-bold rounded p-2 shadow-sm"
                >
                  {isSubmitting ? 'جارٍ الحفظ...' : '✓ خصم الدفعة وتحديث الرصيد'}
                </button>
              </div>
            </div>

            <div className="bg-amber-50/60 p-4 rounded-xl border border-amber-100 space-y-2">
              <span className="text-amber-900 font-bold block">📦 سحب مواد جديدة على الدين (تنقص المستودع وتضاف للحساب فوراً):</span>
              <div className="grid grid-cols-1 md:grid-cols-4 gap-2 items-end">
                <div>
                  <label className="text-slate-600 block mb-0.5">الصنف:</label>
                  <select
                    value={selectedItemId}
                    onChange={e => setSelectedItemId(Number(e.target.value))}
                    className="w-full bg-white border border-slate-300 rounded p-1.5"
                  >
                    {items.map(it => (
                      <option key={it.id} value={it.id}>{it.code} - {it.name} (المتوفر: {it.stockQty} {it.baseUnit})</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="text-slate-600 block mb-0.5">الكمية:</label>
                  <input
                    type="text"
                    value={newQtyStr}
                    onChange={e => setNewQtyStr(e.target.value)}
                    className="w-full bg-white border border-slate-300 rounded p-1.5 font-bold"
                  />
                </div>
                <div>
                  <label className="text-slate-600 block mb-0.5">السعر الإفرادي:</label>
                  <input
                    type="text"
                    value={newPriceStr}
                    onChange={e => setNewPriceStr(e.target.value)}
                    className="w-full bg-white border border-slate-300 rounded p-1.5 font-bold"
                  />
                </div>
                <button
                  onClick={handleAddNewItemToDebt}
                  disabled={isSubmitting}
                  className="bg-amber-600 hover:bg-amber-700 disabled:opacity-50 text-white font-bold p-1.5 rounded shadow-sm"
                >
                  {isSubmitting ? 'جارٍ السحب...' : '+ سحب للمستودع وتثبيت'}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// ==========================================
// 7. ديون التجار وتسجيل الدفعات بالوقت التلقائي
// ==========================================
function MerchantDebtsWorkspace({
  invoices,
  onPayMerchantDebt
}: {
  invoices: AlAmeenInvoice[];
  onPayMerchantDebt: (invId: number, amount: number, notes: string, merchantName: string) => void;
}) {
  const merchantDebts = useMemo(() => {
    return invoices.filter(i => i.type === 'purchase' && i.remainingAmount > 0.001);
  }, [invoices]);

  const total = round2(merchantDebts.reduce((s, i) => s + i.remainingAmount, 0));

  const [activeInv, setActiveInv] = useState<AlAmeenInvoice | null>(null);
  const [payAmountStr, setPayAmountStr] = useState('');
  const [payNotes, setPayNotes] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  return (
    <div className="bg-white border border-slate-200 p-6 rounded-2xl space-y-4 shadow-sm text-xs">
      <div className="flex justify-between items-center border-b pb-3">
        <div>
          <h3 className="font-bold text-sm text-slate-800 flex items-center gap-2">
            <span className="w-3 h-3 bg-[#0288d1] rounded-full inline-block"></span>
            ديون التجار والموردين المستحقة ({merchantDebts.length} فاتورة)
          </h3>
          <p className="text-slate-500 text-[11px]">متابعة فواتير الشراء المعلقة وتسديد الدفعات مع التوثيق الزمني.</p>
        </div>
        <div className="bg-sky-50 border border-sky-200 text-sky-800 px-4 py-2 rounded-xl font-bold font-mono text-sm">
          مجموع المستحقات للتجار: {formatCurr(total)}
        </div>
      </div>

      <div className="border border-slate-200 rounded-xl overflow-x-auto bg-white">
        <table className="w-full text-right text-xs">
          <thead className="bg-slate-50 text-slate-700 font-bold">
            <tr>
              <th className="p-3">رقم الفاتورة</th>
              <th className="p-3">اسم التاجر / المورد</th>
              <th className="p-3">تاريخ الشراء</th>
              <th className="p-3">المواد المستلمة</th>
              <th className="p-3">إجمالي الفاتورة</th>
              <th className="p-3">المسدد له</th>
              <th className="p-3">المتبقي له دين</th>
              <th className="p-3 text-center">تسديد دفعة</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 text-slate-800 font-mono">
            {merchantDebts.length === 0 ? (
              <tr>
                <td colSpan={8} className="p-8 text-center text-slate-400 font-sans">
                  لا توجد أي مستحقات معلقة للتجار حالياً!
                </td>
              </tr>
            ) : (
              merchantDebts.map(inv => (
                <tr key={inv.id} className="hover:bg-slate-50">
                  <td className="p-3 text-[#0288d1] font-bold">{inv.invNumber}</td>
                  <td className="p-3 font-sans font-bold text-slate-900">{inv.merchantName || inv.customerName}</td>
                  <td className="p-3 text-slate-500">{inv.invDate}</td>
                  <td className="p-3 font-sans text-slate-600">
                    {inv.rows.map(r => `${r.itemName} (${r.quantity} ${r.unit})`).join('، ')}
                  </td>
                  <td className="p-3">{formatCurr(inv.grandTotal, inv.currency)}</td>
                  <td className="p-3 text-emerald-600">{formatCurr(inv.paidAmount, inv.currency)}</td>
                  <td className="p-3 font-bold text-rose-600">{formatCurr(inv.remainingAmount, inv.currency)}</td>
                  <td className="p-3 text-center font-sans">
                    <button
                      onClick={() => {
                        setActiveInv(inv);
                        setPayAmountStr(String(inv.remainingAmount));
                      }}
                      className="bg-[#0288d1] hover:bg-[#0277bd] text-white font-bold px-3 py-1.5 rounded-lg shadow-sm"
                    >
                      تسديد دفعة للتاجر
                    </button>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {activeInv && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl w-full max-w-sm p-6 space-y-4 shadow-xl border border-slate-200">
            <h4 className="font-bold text-slate-900 text-sm">تسديد دفعة للتاجر ({activeInv.merchantName || activeInv.customerName})</h4>
            <p className="text-slate-500 text-xs">المتبقي له: {formatCurr(activeInv.remainingAmount, activeInv.currency)}</p>
            <div>
              <label className="text-slate-700 block mb-1">المبلغ المسدد الآن:</label>
              <input
                type="text"
                value={payAmountStr}
                onChange={e => setPayAmountStr(e.target.value)}
                className="w-full bg-slate-50 border border-slate-300 rounded p-2 text-emerald-600 font-bold font-mono text-base"
              />
            </div>
            <div>
              <label className="text-slate-700 block mb-1">ملاحظات / بيان السداد:</label>
              <input
                type="text"
                value={payNotes}
                onChange={e => setPayNotes(e.target.value)}
                placeholder="حوالة، نقدي، دفعة حساب..."
                className="w-full bg-slate-50 border border-slate-300 rounded p-2"
              />
            </div>
            <div className="flex justify-end gap-2 pt-2 border-t">
              <button onClick={() => setActiveInv(null)} className="px-4 py-1.5 bg-slate-100 text-slate-600 rounded">إلغاء</button>
              <button
                onClick={() => {
                  if (isSubmitting) return;
                  const amount = parseDecimal(payAmountStr);
                  if (amount <= 0) return;
                  setIsSubmitting(true);
                  onPayMerchantDebt(activeInv.id, amount, payNotes, activeInv.merchantName || activeInv.customerName);
                  setActiveInv(null);
                  setIsSubmitting(false);
                  alert('تم تسجيل الدفعة المسددة للتاجر وتوثيقها في كشف حسابه بنجاح!');
                }}
                disabled={isSubmitting}
                className="px-5 py-1.5 bg-[#0288d1] disabled:opacity-50 text-white font-bold rounded shadow-sm"
              >
                {isSubmitting ? 'جارٍ التسديد...' : 'تأكيد التسديد'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// ==========================================
// 8. كشف حساب تاجر ومورد تفصيلي (مع حماية تعديل وحذف الدفعات بكلمة مرور)
// ==========================================
function MerchantStatementWorkspace({
  invoices,
  payments,
  onRequestAuth,
  onDeletePayment,
  onEditPayment,
  onPrintStatement
}: {
  invoices: AlAmeenInvoice[];
  payments: PaymentRecord[];
  onRequestAuth: (title: string, desc: string, cb: () => void) => void;
  onDeletePayment: (paymentId: string) => void;
  onEditPayment: (paymentId: string, newAmount: number, newNotes: string) => void;
  onPrintStatement: (merchantName: string, entries: any[], totalCredit: number, totalDebit: number, netDue: number) => void;
}) {
  const merchantInvoices = useMemo(() => invoices.filter(i => i.type === 'purchase'), [invoices]);
  const merchantNames = Array.from(new Set(merchantInvoices.map(i => i.merchantName || i.customerName)));

  const [selectedMerchant, setSelectedMerchant] = useState(merchantNames[0] || '');
  const [filterType, setFilterType] = useState<'all' | 'invoices' | 'payments'>('all');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');

  // نافذة تعديل الدفعة المحمية
  const [editingPay, setEditingPay] = useState<PaymentRecord | null>(null);
  const [newPayAmountStr, setNewPayAmountStr] = useState('');
  const [newPayNotes, setNewPayNotes] = useState('');

  const targetInvoices = merchantInvoices.filter(i => (i.merchantName || i.customerName) === selectedMerchant);
  const targetPayments = payments.filter(p => p.partyType === 'merchant' && p.partyName === selectedMerchant);

  const combinedEntries = useMemo(() => {
    let list: { id?: string; date: string; time: string; type: string; debit: number; credit: number; statement: string; ref: string; isPaymentRecord?: boolean }[] = [];

    if (filterType === 'all' || filterType === 'invoices') {
      targetInvoices.forEach(inv => {
        list.push({
          date: inv.invDate,
          time: inv.invTime,
          type: 'فاتورة توريد بضاعة',
          debit: 0,
          credit: inv.grandTotal,
          statement: `توريد مواد: ${inv.rows.map(r => `${r.itemName} (${r.quantity})`).join('، ')}`,
          ref: inv.invNumber
        });

        const initialPayment = inv.initialPaid !== undefined ? inv.initialPaid : inv.paidAmount;
        if (initialPayment > 0) {
          list.push({
            date: inv.invDate,
            time: inv.invTime,
            type: 'سند تسديد عند الشراء',
            debit: initialPayment,
            credit: 0,
            statement: `دفعة مسددة عند استلام فاتورة #${inv.invNumber}`,
            ref: `PAY-INIT-${inv.invNumber}`
          });
        }
      });
    }

    if (filterType === 'all' || filterType === 'payments') {
      targetPayments.forEach(pay => {
        list.push({
          id: pay.id,
          date: pay.date,
          time: pay.time,
          type: 'سند تسديد دفعة لاحقة',
          debit: pay.amount,
          credit: 0,
          statement: pay.notes,
          ref: pay.id,
          isPaymentRecord: true
        });
      });
    }

    if (startDate) list = list.filter(e => e.date >= startDate);
    if (endDate) list = list.filter(e => e.date <= endDate);

    return list.sort((a, b) => (b.date + b.time).localeCompare(a.date + a.time));
  }, [targetInvoices, targetPayments, filterType, startDate, endDate]);

  const totalCredit = round2(targetInvoices.reduce((s, i) => s + i.grandTotal, 0));
  const totalDebit = round2(
    targetPayments.reduce((s, p) => s + p.amount, 0) +
    targetInvoices.reduce((s, i) => s + (i.initialPaid !== undefined ? i.initialPaid : i.paidAmount), 0)
  );

  const netDueToMerchant = round2(totalCredit - totalDebit);

  return (
    <div className="bg-white border border-slate-200 p-6 rounded-2xl space-y-4 shadow-sm text-xs">
      <div className="flex flex-wrap justify-between items-center border-b pb-3 gap-2">
        <div>
          <h3 className="font-bold text-sm text-slate-800 flex items-center gap-2">
            <span className="w-3 h-3 bg-[#00897b] rounded-full inline-block"></span>
            كشف حساب تاجر / مورد تفصيلي معتمد
          </h3>
          <p className="text-slate-500 text-[11px]">متابعة التوريدات والدفعات وتعديل أو حذف الدفعات بكلمة مرور المدير.</p>
        </div>
        <button
          onClick={() => onPrintStatement(selectedMerchant, combinedEntries, totalCredit, totalDebit, netDueToMerchant)}
          className="bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-300 px-4 py-1.5 rounded-lg shadow-sm font-bold"
        >
          🖨️ طباعة كشف التاجر A4
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-3 bg-slate-50 p-4 rounded-xl border border-slate-200">
        <div>
          <label className="text-slate-700 block mb-1 font-bold">اختر التاجر:</label>
          <select
            value={selectedMerchant}
            onChange={e => setSelectedMerchant(e.target.value)}
            className="w-full bg-white border border-slate-300 rounded p-1.5 font-bold"
          >
            {merchantNames.map((name, i) => (
              <option key={i} value={name}>{name}</option>
            ))}
          </select>
        </div>

        <div>
          <label className="text-slate-700 block mb-1">نوع الحركة:</label>
          <select
            value={filterType}
            onChange={e => setFilterType(e.target.value as any)}
            className="w-full bg-white border border-slate-300 rounded p-1.5"
          >
            <option value="all">جميع الحركات (توريد ودفعات)</option>
            <option value="invoices">فواتير التوريد فقط</option>
            <option value="payments">سندات الدفعات المسددة فقط</option>
          </select>
        </div>

        <div>
          <label className="text-slate-700 block mb-1">من تاريخ:</label>
          <input
            type="date"
            value={startDate}
            onChange={e => setStartDate(e.target.value)}
            className="w-full bg-white border border-slate-300 rounded p-1.5"
          />
        </div>

        <div>
          <label className="text-slate-700 block mb-1">إلى تاريخ:</label>
          <input
            type="date"
            value={endDate}
            onChange={e => setEndDate(e.target.value)}
            className="w-full bg-white border border-slate-300 rounded p-1.5"
          />
        </div>
      </div>

      <div className="grid grid-cols-3 gap-3 bg-slate-50 p-3.5 rounded-xl border border-slate-200 text-center font-mono">
        <div><span className="text-slate-500 block font-sans">مجموع بضاعة التاجر (له):</span><span className="font-bold text-slate-800">{formatCurr(totalCredit)}</span></div>
        <div><span className="text-slate-500 block font-sans">المسدد له (دفعات):</span><span className="font-bold text-emerald-600">{formatCurr(totalDebit)}</span></div>
        <div>
          <span className="text-slate-500 block font-sans">الحالة النهائية:</span>
          {netDueToMerchant > 0.001 ? (
            <span className="font-bold text-rose-600 text-sm">علينا للتاجر: {formatCurr(netDueToMerchant)}</span>
          ) : netDueToMerchant < -0.001 ? (
            <span className="font-bold text-emerald-600 text-sm">رصيد لصالحنا عند التاجر: {formatCurr(Math.abs(netDueToMerchant))}</span>
          ) : (
            <span className="font-bold text-emerald-600 text-sm">مسدد بالكامل ✓</span>
          )}
        </div>
      </div>

      <div className="border border-slate-200 rounded-xl overflow-x-auto bg-white">
        <table className="w-full text-right text-xs">
          <thead className="bg-slate-50 text-slate-700 font-bold border-b">
            <tr>
              <th className="p-3">التاريخ والوقت</th>
              <th className="p-3">نوع الحركة</th>
              <th className="p-3">رقم المرجع</th>
              <th className="p-3">مدين (سددنا له)</th>
              <th className="p-3">دائن (استلمنا منه)</th>
              <th className="p-3">البيان والتفاصيل</th>
              <th className="p-3 text-center">إجراءات الدفعة (محمية)</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 text-slate-800 font-mono">
            {combinedEntries.length === 0 ? (
              <tr><td colSpan={7} className="p-8 text-center text-slate-400 font-sans">لا توجد حركات مسجلة للتاجر وفق الفلاتر المحددة.</td></tr>
            ) : (
              combinedEntries.map((e, idx) => (
                <tr key={idx} className="hover:bg-slate-50">
                  <td className="p-3 text-slate-500">{e.date} {e.time}</td>
                  <td className="p-3 font-sans font-bold text-slate-900">{e.type}</td>
                  <td className="p-3 text-teal-600 font-bold">{e.ref}</td>
                  <td className="p-3 text-emerald-600 font-bold">{e.debit > 0 ? formatCurr(e.debit) : '-'}</td>
                  <td className="p-3 text-rose-600 font-bold">{e.credit > 0 ? formatCurr(e.credit) : '-'}</td>
                  <td className="p-3 font-sans text-slate-600">{e.statement}</td>
                  <td className="p-3 text-center font-sans space-x-1 space-x-reverse">
                    {e.isPaymentRecord && e.id && (
                      <>
                        <button
                          onClick={() => {
                            const rec = payments.find(p => p.id === e.id);
                            if (!rec) return;
                            onRequestAuth('تعديل دفعة تاجر', `تعديل السند (${rec.id}) المسدد للتاجر (${rec.partyName}) يتطلب كلمة مرور المدير.`, () => {
                              setEditingPay(rec);
                              setNewPayAmountStr(String(rec.amount));
                              setNewPayNotes(rec.notes);
                            });
                          }}
                          className="bg-amber-100 hover:bg-amber-200 text-amber-900 font-bold px-2 py-0.5 rounded border border-amber-300"
                        >
                          ✏️ تعديل
                        </button>
                        <button
                          onClick={() => {
                            onRequestAuth('حذف دفعة تاجر', `حذف السند (${e.id}) وإعادة المبلغ إلى ذمة التاجر يتطلب كلمة مرور المدير.`, () => {
                              onDeletePayment(e.id!);
                            });
                          }}
                          className="bg-rose-100 hover:bg-rose-200 text-rose-800 font-bold px-2 py-0.5 rounded border border-rose-300"
                        >
                          🗑️ حذف
                        </button>
                      </>
                    )}
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {/* نافذة تعديل الدفعة المحمية بعد إدخال كلمة المرور */}
      {editingPay && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl w-full max-w-sm p-6 space-y-3 border border-slate-200 shadow-xl">
            <h4 className="font-bold text-slate-900 text-sm">تعديل سند سداد التاجر ({editingPay.partyName})</h4>
            <div>
              <label className="text-slate-700 block mb-1">المبلغ الجديد ($):</label>
              <input
                type="text"
                value={newPayAmountStr}
                onChange={e => setNewPayAmountStr(e.target.value)}
                className="w-full bg-slate-50 border border-slate-300 rounded p-1.5 text-emerald-600 font-bold font-mono"
              />
            </div>
            <div>
              <label className="text-slate-700 block mb-1">البيان والملاحظات:</label>
              <input
                type="text"
                value={newPayNotes}
                onChange={e => setNewPayNotes(e.target.value)}
                className="w-full bg-slate-50 border border-slate-300 rounded p-1.5"
              />
            </div>
            <div className="flex justify-end gap-2 pt-2 border-t">
              <button onClick={() => setEditingPay(null)} className="px-4 py-1.5 bg-slate-100 text-slate-600 rounded">إلغاء</button>
              <button
                onClick={() => {
                  const amt = parseDecimal(newPayAmountStr);
                  if (amt <= 0) return;
                  onEditPayment(editingPay.id, amt, newPayNotes);
                  setEditingPay(null);
                }}
                className="px-5 py-1.5 bg-[#00897b] text-white font-bold rounded shadow-sm"
              >
                حفظ التعديل
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// ==========================================
// 9. المصاريف اليومية وتخصم من الربح
// ==========================================
function DailyExpensesWorkspace({
  expenses,
  onRequestAuth,
  onAddExpense,
  onDeleteExpense
}: {
  expenses: ExpenseItem[];
  onRequestAuth: (title: string, desc: string, cb: () => void) => void;
  onAddExpense: (e: ExpenseItem) => void;
  onDeleteExpense: (id: number) => void;
}) {
  const [title, setTitle] = useState('');
  const [category, setCategory] = useState<ExpenseItem['category']>('كهرباء وإنارة');
  const [amountStr, setAmountStr] = useState('');
  const [notes, setNotes] = useState('');

  const total = round2(expenses.reduce((s, e) => s + e.amount, 0));

  const add = (e: React.FormEvent) => {
    e.preventDefault();
    const amount = parseDecimal(amountStr);
    if (amount <= 0 || !title.trim()) return;

    onAddExpense({
      id: Date.now(),
      title: title.trim(),
      category,
      amount,
      currency: 'USD',
      date: new Date().toISOString().split('T')[0],
      time: new Date().toLocaleTimeString('ar-SY', { hour: '2-digit', minute: '2-digit' }),
      notes
    });

    setTitle('');
    setAmountStr('');
    setNotes('');
  };

  return (
    <div className="bg-white border border-slate-200 p-6 rounded-2xl space-y-4 shadow-sm text-xs">
      <div className="flex justify-between items-center border-b pb-3">
        <div>
          <h3 className="font-bold text-sm text-slate-800 flex items-center gap-2">
            <span className="w-3 h-3 bg-[#43a047] rounded-full inline-block"></span>
            المصاريف اليومية التشغيلية (تُخصم من صافي الأرباح)
          </h3>
          <p className="text-slate-500 text-[11px]">إيجار، كهرباء، رواتب، ضيافة، صيانة، نقل.</p>
        </div>
        <div className="bg-emerald-50 border border-emerald-200 text-emerald-800 px-4 py-2 rounded-xl font-bold font-mono text-sm">
          إجمالي المصروفات: {formatCurr(total)}
        </div>
      </div>

      <form onSubmit={add} className="grid grid-cols-1 md:grid-cols-5 gap-2 bg-slate-50 p-4 rounded-xl border border-slate-200 items-end">
        <div>
          <label className="text-slate-700 block mb-1">بيان المصروف:</label>
          <input type="text" required placeholder="فاتورة كهرباء، أجور..." value={title} onChange={e => setTitle(e.target.value)} className="w-full bg-white border border-slate-300 rounded p-2" />
        </div>
        <div>
          <label className="text-slate-700 block mb-1">البند:</label>
          <select value={category} onChange={e => setCategory(e.target.value as any)} className="w-full bg-white border border-slate-300 rounded p-2">
            <option value="كهرباء وإنارة">كهرباء وإنارة</option>
            <option value="إيجار المحل">إيجار المحل</option>
            <option value="أجور عمال">أجور عمال</option>
            <option value="شحن ونقل">شحن ونقل</option>
            <option value="صيانة">صيانة</option>
            <option value="نثريات وضيافة">نثريات وضيافة</option>
          </select>
        </div>
        <div>
          <label className="text-slate-700 block mb-1">المبلغ ($):</label>
          <input type="text" required value={amountStr} onChange={e => setAmountStr(e.target.value)} className="w-full bg-white border border-slate-300 rounded p-2 text-rose-600 font-bold font-mono" />
        </div>
        <div>
          <label className="text-slate-700 block mb-1">ملاحظات:</label>
          <input type="text" value={notes} onChange={e => setNotes(e.target.value)} className="w-full bg-white border border-slate-300 rounded p-2" />
        </div>
        <button type="submit" className="bg-[#43a047] hover:bg-[#388e3c] text-white font-bold p-2.5 rounded shadow-sm">
          + تسجيل المصروف
        </button>
      </form>

      <div className="border border-slate-200 rounded-xl overflow-x-auto bg-white">
        <table className="w-full text-right text-xs">
          <thead className="bg-slate-50 text-slate-700 font-bold">
            <tr>
              <th className="p-3">التاريخ والوقت</th>
              <th className="p-3">بيان المصروف</th>
              <th className="p-3">التصنيف</th>
              <th className="p-3">المبلغ</th>
              <th className="p-3">الملاحظات</th>
              <th className="p-3 text-center">حذف</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 text-slate-800 font-mono">
            {expenses.map(e => (
              <tr key={e.id}>
                <td className="p-3 text-slate-400">{e.date} {e.time}</td>
                <td className="p-3 font-sans font-bold text-slate-900">{e.title}</td>
                <td className="p-3 font-sans text-emerald-700">{e.category}</td>
                <td className="p-3 font-bold text-rose-600">-{formatCurr(e.amount, e.currency)}</td>
                <td className="p-3 font-sans text-slate-400">{e.notes || '-'}</td>
                <td className="p-3 text-center font-sans">
                  <button
                    onClick={() => {
                      onRequestAuth('حذف مصروف', `حذف هذا المصروف (${e.title}) يتطلب كلمة مرور المدير.`, () => {
                        onDeleteExpense(e.id);
                      });
                    }}
                    className="text-rose-500 font-bold hover:underline"
                  >
                    ✕ حذف
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

// ==========================================
// 10. بضاعة مرتجعة مع إظهار تفاصيل المواد المأخوذة
// ==========================================
function ReturnsWorkspace({
  invoices,
  items,
  onProcessReturn
}: {
  invoices: AlAmeenInvoice[];
  items: AlAmeenItem[];
  onProcessReturn: (retInv: AlAmeenInvoice, updatedOrigInv: AlAmeenInvoice, updatedItems: AlAmeenItem[]) => void;
}) {
  const [searchCustomer, setSearchCustomer] = useState('');
  const saleInvoices = useMemo(() => invoices.filter(i => i.type === 'sale'), [invoices]);

  const filteredInvoices = useMemo(() => {
    return saleInvoices.filter(i => i.customerName.toLowerCase().includes(searchCustomer.toLowerCase()));
  }, [saleInvoices, searchCustomer]);

  const [selectedInvId, setSelectedInvId] = useState<number>(filteredInvoices[0]?.id || 0);

  useEffect(() => {
    if (filteredInvoices.length > 0 && !filteredInvoices.find(i => i.id === selectedInvId)) {
      setSelectedInvId(filteredInvoices[0].id);
    }
  }, [filteredInvoices]);

  const targetInv = invoices.find(i => i.id === selectedInvId);
  const [returnItemId, setReturnItemId] = useState<number>(0);
  const [returnQtyStr, setReturnQtyStr] = useState('1');

  useEffect(() => {
    if (targetInv && targetInv.rows.length > 0) {
      setReturnItemId(targetInv.rows[0].itemId);
      setReturnQtyStr('1');
    }
  }, [selectedInvId]);

  const selectedRow = targetInv?.rows.find(r => r.itemId === returnItemId);

  const executeReturn = () => {
    const returnQty = parseDecimal(returnQtyStr);
    if (!targetInv || !selectedRow || returnQty <= 0) return;

    if (returnQty > selectedRow.quantity) {
      alert(`لا يمكن إرجاع كمية (${returnQty}) أكبر من المشتراة في الفاتورة (${selectedRow.quantity})!`);
      return;
    }

    const updatedItems = items.map(it => {
      if (it.id === returnItemId) {
        return { ...it, stockQty: round2(it.stockQty + returnQty) };
      }
      return it;
    });

    const remainingInInvoice = round2(selectedRow.quantity - returnQty);
    const returnCashValue = round2(returnQty * selectedRow.price);

    const newRows = targetInv.rows
      .map(r => {
        if (r.itemId === returnItemId) {
          if (remainingInInvoice <= 0) return null;
          return { ...r, quantity: remainingInInvoice, total: round2(remainingInInvoice * r.price) };
        }
        return r;
      })
      .filter(Boolean) as InvoiceRow[];

    const newGrandTotal = Math.max(0, round2(targetInv.grandTotal - returnCashValue));
    const newRemaining = Math.max(0, round2(targetInv.remainingAmount - returnCashValue));

    const updatedOrigInv: AlAmeenInvoice = {
      ...targetInv,
      rows: newRows,
      subTotal: newGrandTotal,
      grandTotal: newGrandTotal,
      remainingAmount: newRemaining
    };

    const retInv: AlAmeenInvoice = {
      id: Date.now(),
      invNumber: `RET-${Date.now().toString().slice(-6)}`,
      type: 'return',
      customerName: targetInv.customerName,
      customerPhone: targetInv.customerPhone,
      rows: [{
        ...selectedRow,
        quantity: returnQty,
        total: returnCashValue
      }],
      subTotal: returnCashValue,
      discount: 0,
      grandTotal: returnCashValue,
      initialPaid: returnCashValue,
      paidAmount: returnCashValue,
      remainingAmount: 0,
      currency: targetInv.currency,
      exchangeRate: targetInv.exchangeRate,
      invDate: new Date().toISOString().split('T')[0],
      invTime: new Date().toLocaleTimeString('ar-SY', { hour: '2-digit', minute: '2-digit' }),
      notes: `مرتجع من الفاتورة رقم #${targetInv.invNumber}`,
      origInvNumber: targetInv.invNumber
    };

    onProcessReturn(retInv, updatedOrigInv, updatedItems);
    alert(`تم بنجاح إرجاع (${returnQty}) للمستودع، وتحديث الكمية بالفاتورة الأصلية إلى (${remainingInInvoice})، ودمج السجلات وخصم القيمة من المالية!`);
  };

  return (
    <div className="bg-white border border-slate-200 p-6 rounded-2xl max-w-2xl mx-auto space-y-4 shadow-sm text-xs">
      <h3 className="font-bold text-sm text-slate-800 flex items-center gap-2 border-b pb-3">
        <span className="w-3 h-3 bg-[#f4511e] rounded-full inline-block"></span>
        بضاعة مرتجعة - فتح فاتورة الزبون وعرض كامل المواد المأخوذة لإرجاع المحدد
      </h3>

      <div className="space-y-3">
        <div>
          <label className="text-slate-700 block mb-1 font-bold">ابحث باسم الزبون لعرض فواتيره:</label>
          <input
            type="text"
            placeholder="اكتب اسم الزبون..."
            value={searchCustomer}
            onChange={e => setSearchCustomer(e.target.value)}
            className="w-full bg-slate-50 border border-slate-300 rounded p-2 font-bold"
          />
        </div>

        <div>
          <label className="text-slate-700 block mb-1">اختر الفاتورة المسحوبة للزبون:</label>
          <select value={selectedInvId} onChange={e => setSelectedInvId(Number(e.target.value))} className="w-full bg-slate-50 border border-slate-300 rounded p-2 font-bold">
            {filteredInvoices.map(i => (
              <option key={i.id} value={i.id}>فاتورة #{i.invNumber} - الزبون: {i.customerName} ({i.invDate}) - القيمة: {formatCurr(i.grandTotal, i.currency)}</option>
            ))}
          </select>
        </div>

        {targetInv && (
          <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-3">
            <div>
              <span className="text-slate-700 font-bold block mb-1">المواد التي أخذها الزبون في هذه الفاتورة:</span>
              <div className="border border-slate-200 rounded-lg max-h-32 overflow-y-auto bg-white mb-2">
                <table className="w-full text-right text-xs">
                  <thead className="bg-slate-100 font-bold">
                    <tr>
                      <th className="p-1.5">المادة</th>
                      <th className="p-1.5">الكمية المسحوبة</th>
                      <th className="p-1.5">السعر</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {targetInv.rows.map((r, idx) => (
                      <tr key={idx}>
                        <td className="p-1.5 font-bold">{r.itemName}</td>
                        <td className="p-1.5">{r.quantity} {r.unit}</td>
                        <td className="p-1.5">{formatCurr(r.price, targetInv.currency)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            <div>
              <label className="text-slate-700 block mb-1 font-bold">اختر المادة المراد إرجاعها منها:</label>
              <select value={returnItemId} onChange={e => setReturnItemId(Number(e.target.value))} className="w-full bg-white border border-slate-300 rounded p-2 font-bold">
                {targetInv.rows.map(r => (
                  <option key={r.itemId} value={r.itemId}>{r.itemName} (الكمية المتبقية لديه بالفاتورة: {r.quantity} {r.unit})</option>
                ))}
              </select>
            </div>

            {selectedRow && (
              <div className="grid grid-cols-2 gap-3 bg-white p-3 rounded-lg border border-slate-200">
                <div>
                  <label className="text-slate-700 block mb-1">الكمية المراد إرجاعها للمستودع:</label>
                  <input
                    type="text"
                    value={returnQtyStr}
                    onChange={e => setReturnQtyStr(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-300 rounded p-2 font-bold font-mono text-center"
                  />
                  <span className="text-[10px] text-slate-500 block mt-1">
                    المتبقي بالفاتورة بعدها: {Math.max(0, round2(selectedRow.quantity - parseDecimal(returnQtyStr)))}
                  </span>
                </div>
                <div>
                  <label className="text-slate-700 block mb-1">المبلغ المخصوم والمعاد للزبون:</label>
                  <div className="p-2 bg-slate-50 border border-slate-300 rounded text-rose-600 font-bold font-mono">
                    {formatCurr(round2(parseDecimal(returnQtyStr) * selectedRow.price), targetInv.currency)}
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

        <button onClick={executeReturn} className="w-full py-2.5 bg-[#f4511e] hover:bg-[#e64a19] text-white font-bold rounded-xl shadow-md">
          تأكيد المرتجع، إنقاص الفاتورة، ودمج الكميات بالمستودع
        </button>
      </div>
    </div>
  );
}

// ==========================================
// 11. دليل بطاقات المواد وطباعة جرد المستودع
// ==========================================
function ItemsManagementWorkspace({
  items,
  onRequestAuth,
  onSaveItem,
  onUpdateItem,
  onDeleteItem,
  onPrintInventory
}: {
  items: AlAmeenItem[];
  onRequestAuth: (title: string, desc: string, cb: () => void) => void;
  onSaveItem: (item: AlAmeenItem) => void;
  onUpdateItem: (item: AlAmeenItem) => void;
  onDeleteItem: (id: number) => void;
  onPrintInventory: () => void;
}) {
  const [searchTerm, setSearchTerm] = useState('');
  const [showAdd, setShowAdd] = useState(false);
  const [editingItem, setEditingItem] = useState<AlAmeenItem | null>(null);

  const [code, setCode] = useState('');
  const [name, setName] = useState('');
  const [category, setCategory] = useState<AlAmeenItem['category']>('خردة');
  const [baseUnit, setBaseUnit] = useState<AlAmeenItem['baseUnit']>('كيلو غرام');
  const [costStr, setCostStr] = useState('0');
  const [priceStr, setPriceStr] = useState('0');
  const [stockStr, setStockStr] = useState('0');
  const [minStockStr, setMinStockStr] = useState('10');

  const filteredItems = useMemo(() => {
    return items.filter(
      i => i.name.toLowerCase().includes(searchTerm.toLowerCase()) || i.code.includes(searchTerm)
    );
  }, [items, searchTerm]);

  const saveNew = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !code.trim()) return;

    onSaveItem({
      id: Date.now(),
      code: code.trim(),
      name: name.trim(),
      category,
      baseUnit,
      costPrice: parseDecimal(costStr),
      salePrice: parseDecimal(priceStr),
      stockQty: parseDecimal(stockStr),
      minStock: parseDecimal(minStockStr)
    });

    setShowAdd(false);
  };

  const saveEdit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingItem) return;
    onUpdateItem(editingItem);
    setEditingItem(null);
  };

  return (
    <div className="bg-white border border-slate-200 p-6 rounded-2xl space-y-4 shadow-sm text-xs">
      <div className="flex flex-wrap justify-between items-center border-b pb-3 gap-2">
        <div>
          <h3 className="font-bold text-sm text-slate-800 flex items-center gap-2">
            <span className="w-3 h-3 bg-[#1e88e5] rounded-full inline-block"></span>
            دليل المواد وجرد المستودع الكامل
          </h3>
          <p className="text-slate-500 text-[11px]">البحث بالاسم، منع التكرار، التعديل الكامل مع الكسور، والحذف المحمي بكلمة مرور.</p>
        </div>
        <div className="flex gap-2">
          <button onClick={onPrintInventory} className="bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold px-4 py-2 rounded-xl border border-slate-300 shadow-sm flex items-center gap-1">
            🖨️ طباعة قائمة المستودع A4
          </button>
          <button onClick={() => { setCode(`ITM-${Math.floor(100 + Math.random() * 900)}`); setShowAdd(true); }} className="bg-[#1e88e5] hover:bg-[#1976d2] text-white font-bold px-4 py-2 rounded-xl shadow-sm">
            + بطاقة مادة جديدة
          </button>
        </div>
      </div>

      <div className="bg-slate-50 p-3 rounded-xl border border-slate-200">
        <input
          type="text"
          placeholder="ابحث عن مادة بالاسم أو الكود في المستودع..."
          value={searchTerm}
          onChange={e => setSearchTerm(e.target.value)}
          className="w-full bg-white border border-slate-300 rounded p-2 text-slate-900 font-bold"
        />
      </div>

      <div className="border border-slate-200 rounded-xl overflow-x-auto bg-white">
        <table className="w-full text-right text-xs">
          <thead className="bg-slate-50 text-slate-700 font-bold">
            <tr>
              <th className="p-3">رمز المادة</th>
              <th className="p-3">اسم المادة</th>
              <th className="p-3">التصنيف</th>
              <th className="p-3">الوحدة الأساسية</th>
              <th className="p-3">الرصيد المتاح</th>
              <th className="p-3">حد النفاذ والتنبيه</th>
              <th className="p-3">سعر الشراء</th>
              <th className="p-3">سعر البيع</th>
              <th className="p-3">حالة الرصيد</th>
              <th className="p-3 text-center">إجراءات</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 text-slate-800 font-mono">
            {filteredItems.map(it => {
              const isOut = it.stockQty <= 0;
              const isLow = it.stockQty > 0 && it.stockQty <= it.minStock;

              return (
                <tr key={it.id} className="hover:bg-slate-50">
                  <td className="p-3 text-[#1e88e5] font-bold">{it.code}</td>
                  <td className="p-3 font-sans font-bold text-slate-900">{it.name}</td>
                  <td className="p-3 font-sans text-teal-700">{it.category}</td>
                  <td className="p-3 font-sans">{it.baseUnit}</td>
                  <td className="p-3 font-bold text-slate-900">{it.stockQty} {it.baseUnit}</td>
                  <td className="p-3 font-sans font-bold text-amber-700">{it.minStock}</td>
                  <td className="p-3">{formatCurr(it.costPrice)}</td>
                  <td className="p-3 font-bold text-emerald-600">{formatCurr(it.salePrice)}</td>
                  <td className="p-3 font-sans">
                    {isOut ? (
                      <span className="text-white bg-rose-600 px-2.5 py-0.5 rounded-full font-bold shadow-sm">
                        ⛔ تم نفاذ الكمية
                      </span>
                    ) : isLow ? (
                      <span className="text-amber-800 bg-amber-100 border border-amber-300 px-2.5 py-0.5 rounded-full font-bold">
                        ⚠️ قارب على النفاذ
                      </span>
                    ) : (
                      <span className="text-emerald-700 bg-emerald-50 px-2.5 py-0.5 rounded-full font-bold">
                        ✓ متوفر
                      </span>
                    )}
                  </td>
                  <td className="p-3 text-center font-sans space-x-1 space-x-reverse">
                    <button
                      onClick={() => setEditingItem({ ...it })}
                      className="bg-amber-100 hover:bg-amber-200 text-amber-900 px-2.5 py-1 rounded font-bold border border-amber-300"
                    >
                      ✏️ تعديل
                    </button>
                    <button
                      onClick={() => {
                        onRequestAuth('حذف مادة من المستودع', `حذف المادة (${it.name}) يتطلب كلمة مرور المدير لتأكيد العملية.`, () => {
                          onDeleteItem(it.id);
                        });
                      }}
                      className="bg-rose-100 hover:bg-rose-200 text-rose-800 px-2.5 py-1 rounded font-bold border border-rose-300"
                    >
                      🗑️ حذف
                    </button>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {showAdd && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4 z-50">
          <form onSubmit={saveNew} className="bg-white border border-slate-200 rounded-2xl w-full max-w-md p-6 space-y-3 shadow-2xl">
            <h4 className="font-bold text-slate-900 text-sm">إضافة بطاقة مادة جديدة بالمستودع</h4>
            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="text-slate-700 block mb-0.5">رمز المادة:</label>
                <input type="text" required value={code} onChange={e => setCode(e.target.value)} className="w-full bg-slate-50 border border-slate-300 rounded p-1.5" />
              </div>
              <div>
                <label className="text-slate-700 block mb-0.5">التصنيف:</label>
                <select value={category} onChange={e => setCategory(e.target.value as any)} className="w-full bg-slate-50 border border-slate-300 rounded p-1.5 font-bold">
                  <option value="كهربائيات">كهربائيات</option>
                  <option value="صحية">صحية</option>
                  <option value="خردة">خردة (حديد، نحاس، بلاستيك)</option>
                  <option value="أدوات أخرى">أدوات أخرى</option>
                </select>
              </div>
            </div>

            <div>
              <label className="text-slate-700 block mb-0.5">اسم المادة:</label>
              <input type="text" required value={name} onChange={e => setName(e.target.value)} className="w-full bg-slate-50 border border-slate-300 rounded p-1.5 font-bold" />
            </div>

            <div className="grid grid-cols-3 gap-2">
              <div>
                <label className="text-slate-700 block mb-0.5">الوحدة:</label>
                <select value={baseUnit} onChange={e => setBaseUnit(e.target.value as any)} className="w-full bg-slate-50 border border-slate-300 rounded p-1.5 font-bold">
                  <option value="متر">متر</option>
                  <option value="قطعة">قطعة</option>
                  <option value="طقم">طقم</option>
                  <option value="كيلو غرام">كيلو غرام</option>
                </select>
              </div>
              <div>
                <label className="text-slate-700 block mb-0.5">الرصيد الأولي:</label>
                <input type="text" value={stockStr} onChange={e => setStockStr(e.target.value)} className="w-full bg-slate-50 border border-slate-300 rounded p-1.5 font-mono" />
              </div>
              <div>
                <label className="text-slate-700 block mb-0.5">حد التنبيه اليدوي:</label>
                <input type="text" value={minStockStr} onChange={e => setMinStockStr(e.target.value)} className="w-full bg-slate-50 border border-slate-300 rounded p-1.5 text-amber-700 font-bold font-mono" />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="text-slate-700 block mb-0.5">سعر التكلفة ($):</label>
                <input type="text" value={costStr} onChange={e => setCostStr(e.target.value)} className="w-full bg-slate-50 border border-slate-300 rounded p-1.5 font-mono" />
              </div>
              <div>
                <label className="text-slate-700 block mb-0.5">سعر البيع ($):</label>
                <input type="text" value={priceStr} onChange={e => setPriceStr(e.target.value)} className="w-full bg-slate-50 border border-slate-300 rounded p-1.5 text-emerald-600 font-bold font-mono" />
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-2 border-t">
              <button type="button" onClick={() => setShowAdd(false)} className="px-4 py-1.5 bg-slate-100 text-slate-600 rounded">إلغاء</button>
              <button type="submit" className="px-5 py-1.5 bg-[#1e88e5] text-white font-bold rounded shadow-sm">حفظ المادة</button>
            </div>
          </form>
        </div>
      )}

      {/* نافذة تعديل مادة موجودة في المستودع */}
      {editingItem && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4 z-50">
          <form onSubmit={saveEdit} className="bg-white border border-slate-200 rounded-2xl w-full max-w-md p-6 space-y-3 shadow-2xl">
            <h4 className="font-bold text-slate-900 text-sm">تعديل بيانات المادة ({editingItem.name})</h4>
            <div>
              <label className="text-slate-700 block mb-0.5">اسم المادة:</label>
              <input
                type="text"
                required
                value={editingItem.name}
                onChange={e => setEditingItem({ ...editingItem, name: e.target.value })}
                className="w-full bg-slate-50 border border-slate-300 rounded p-1.5 font-bold"
              />
            </div>
            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="text-slate-700 block mb-0.5">الكمية المتوفرة بالمستودع:</label>
                <input
                  type="text"
                  value={editingItem.stockQty}
                  onChange={e => setEditingItem({ ...editingItem, stockQty: parseDecimal(e.target.value) })}
                  className="w-full bg-slate-50 border border-slate-300 rounded p-1.5 font-mono font-bold"
                />
              </div>
              <div>
                <label className="text-slate-700 block mb-0.5">حد النفاذ والتنبيه:</label>
                <input
                  type="text"
                  value={editingItem.minStock}
                  onChange={e => setEditingItem({ ...editingItem, minStock: parseDecimal(e.target.value) })}
                  className="w-full bg-slate-50 border border-slate-300 rounded p-1.5 text-amber-700 font-bold font-mono"
                />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="text-slate-700 block mb-0.5">سعر التكلفة ($):</label>
                <input
                  type="text"
                  value={editingItem.costPrice}
                  onChange={e => setEditingItem({ ...editingItem, costPrice: parseDecimal(e.target.value) })}
                  className="w-full bg-slate-50 border border-slate-300 rounded p-1.5 font-mono"
                />
              </div>
              <div>
                <label className="text-slate-700 block mb-0.5">سعر البيع ($):</label>
                <input
                  type="text"
                  value={editingItem.salePrice}
                  onChange={e => setEditingItem({ ...editingItem, salePrice: parseDecimal(e.target.value) })}
                  className="w-full bg-slate-50 border border-slate-300 rounded p-1.5 text-emerald-600 font-bold font-mono"
                />
              </div>
            </div>
            <div className="flex justify-end gap-2 pt-2 border-t">
              <button type="button" onClick={() => setEditingItem(null)} className="px-4 py-1.5 bg-slate-100 text-slate-600 rounded">إلغاء</button>
              <button type="submit" className="px-5 py-1.5 bg-emerald-600 text-white font-bold rounded shadow-sm">حفظ التعديلات</button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
}

// ==========================================
// 12. أرشيف الفواتير المعتمد (محمي تماماً من التعديل مع فلاتر كاملة وحذف بكلمة سر)
// ==========================================
function InvoiceArchiveWorkspace({
  invoices,
  onRequestAuth,
  onDeleteInvoice,
  onPrintA4,
  onPrintFilteredArchive
}: {
  invoices: AlAmeenInvoice[];
  onRequestAuth: (title: string, desc: string, cb: () => void) => void;
  onDeleteInvoice: (invId: number) => void;
  onPrintA4: (inv: AlAmeenInvoice) => void;
  onPrintFilteredArchive: (filteredList: AlAmeenInvoice[], filterName: string) => void;
}) {
  const [filterType, setFilterType] = useState<'all' | 'sale' | 'purchase' | 'return'>('all');
  const [search, setSearch] = useState('');
  const [selectedInvoice, setSelectedInvoice] = useState<AlAmeenInvoice | null>(null);

  const filtered = invoices.filter(inv => {
    const matchType = filterType === 'all' || inv.type === filterType;
    const matchSearch = inv.customerName.toLowerCase().includes(search.toLowerCase()) || inv.invNumber.includes(search);
    return matchType && matchSearch;
  });

  const filterNames = {
    all: 'جميع العمليات',
    sale: 'المبيعات',
    purchase: 'المشتريات',
    return: 'المرتجعات'
  };

  return (
    <div className="bg-white border border-slate-200 p-6 rounded-2xl space-y-4 shadow-sm text-xs">
      <div className="flex flex-wrap justify-between items-center border-b pb-3 gap-2">
        <div>
          <h3 className="font-bold text-sm text-slate-800 flex items-center gap-2">
            <span className="w-3 h-3 bg-[#fb8c00] rounded-full inline-block"></span>
            أرشيف الفواتير المعتمد (محمي من التعديل اليدوي - للعرض والطباعة فقط)
          </h3>
          <p className="text-slate-500 text-[11px]">سجل رسمي محمي لجميع العمليات مع خيارات تصفية وطباعة متقدمة.</p>
        </div>
        <div className="flex gap-2 items-center">
          <input
            type="text"
            placeholder="بحث برقم الفاتورة أو الاسم..."
            value={search}
            onChange={e => setSearch(e.target.value)}
            className="bg-slate-50 border border-slate-300 rounded px-3 py-1.5"
          />
          <select value={filterType} onChange={e => setFilterType(e.target.value as any)} className="bg-slate-50 border border-slate-300 rounded px-3 py-1.5 font-bold">
            <option value="all">جميع العمليات</option>
            <option value="sale">المبيعات</option>
            <option value="purchase">المشتريات</option>
            <option value="return">المرتجعات</option>
          </select>
          <button
            onClick={() => onPrintFilteredArchive(filtered, filterNames[filterType])}
            className="bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-300 px-3 py-1.5 rounded font-bold shadow-sm"
          >
            🖨️ طباعة قائمة الأرشيف
          </button>
        </div>
      </div>

      <div className="border border-slate-200 rounded-xl overflow-x-auto bg-white">
        <table className="w-full text-right text-xs">
          <thead className="bg-slate-50 text-slate-700 font-bold">
            <tr>
              <th className="p-3">رقم الفاتورة</th>
              <th className="p-3">نوع الفاتورة</th>
              <th className="p-3">الطرف (السيد: / التاجر)</th>
              <th className="p-3">رقم الجوال</th>
              <th className="p-3">تاريخ ووقت الفاتورة</th>
              <th className="p-3">الإجمالي</th>
              <th className="p-3">المتبقي دين</th>
              <th className="p-3 text-center">إجراءات العرض والطباعة</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 text-slate-800 font-mono">
            {filtered.map(inv => (
              <tr key={inv.id} className="hover:bg-slate-50">
                <td className="p-3 text-[#fb8c00] font-bold">{inv.invNumber}</td>
                <td className="p-3 font-sans font-bold">
                  {inv.type === 'sale' ? <span className="text-emerald-600">مبيعات</span> : inv.type === 'purchase' ? <span className="text-blue-600">مشتريات</span> : <span className="text-rose-600">مرتجع</span>}
                </td>
                <td className="p-3 font-sans font-bold text-slate-900">{inv.customerName}</td>
                <td className="p-3 text-slate-500">{inv.customerPhone}</td>
                <td className="p-3 text-slate-500">{inv.invDate} {inv.invTime}</td>
                <td className="p-3 font-bold">{formatCurr(inv.grandTotal, inv.currency)}</td>
                <td className="p-3 text-rose-600 font-bold">{formatCurr(inv.remainingAmount, inv.currency)}</td>
                <td className="p-3 text-center font-sans space-x-1 space-x-reverse">
                  <button onClick={() => setSelectedInvoice(inv)} className="bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold px-2.5 py-1 rounded border border-slate-300">
                    👁️ عرض
                  </button>
                  <button onClick={() => onPrintA4(inv)} className="bg-amber-50 hover:bg-amber-100 text-amber-900 font-bold px-2.5 py-1 rounded border border-amber-300">
                    🖨️ طباعة
                  </button>
                  <button
                    onClick={() => {
                      onRequestAuth('حذف فاتورة من الأرشيف', `حذف الفاتورة #${inv.invNumber} وإلغاء أثرها المالي والمخزني يتطلب كلمة مرور المدير.`, () => {
                        onDeleteInvoice(inv.id);
                      });
                    }}
                    className="bg-rose-50 hover:bg-rose-100 text-rose-700 font-bold px-2 py-1 rounded border border-rose-200"
                  >
                    🗑️ حذف
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {selectedInvoice && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4 z-50 overflow-y-auto">
          <div className="bg-white rounded-2xl w-full max-w-2xl p-6 space-y-4 shadow-2xl border border-slate-200">
            <div className="flex justify-between items-center border-b pb-3">
              <div>
                <h4 className="font-bold text-slate-900 text-base">استعراض أرشيف الفاتورة #{selectedInvoice.invNumber}</h4>
                <p className="text-slate-500 text-xs">السيد: {selectedInvoice.customerName} | التاريخ: {selectedInvoice.invDate} {selectedInvoice.invTime}</p>
              </div>
              <button onClick={() => setSelectedInvoice(null)} className="text-slate-400 hover:text-slate-700 font-bold text-lg">✕</button>
            </div>

            {selectedInvoice.notes && (
              <div className="bg-amber-50 p-2.5 rounded-lg border border-amber-200 text-amber-900 font-sans">
                <strong>الملاحظات المحفوظة:</strong> {selectedInvoice.notes}
              </div>
            )}

            <div className="border border-slate-200 rounded-xl overflow-x-auto">
              <table className="w-full text-right text-xs">
                <thead className="bg-slate-50 font-bold">
                  <tr>
                    <th className="p-2">#</th>
                    <th className="p-2">المادة</th>
                    <th className="p-2">الكمية</th>
                    <th className="p-2">السعر</th>
                    <th className="p-2">الإجمالي</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 font-mono">
                  {selectedInvoice.rows.map((r, idx) => (
                    <tr key={idx}>
                      <td className="p-2 text-slate-400">{idx + 1}</td>
                      <td className="p-2 font-sans font-bold text-slate-900">{r.itemName}</td>
                      <td className="p-2">{r.quantity} {r.unit}</td>
                      <td className="p-2">{formatCurr(r.price, selectedInvoice.currency)}</td>
                      <td className="p-2 font-bold">{formatCurr(r.total, selectedInvoice.currency)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <div className="grid grid-cols-3 gap-2 bg-slate-50 p-3 rounded-xl border border-slate-200 font-mono font-bold text-center">
              <div><span className="text-slate-500 block font-sans">الإجمالي:</span>{formatCurr(selectedInvoice.grandTotal, selectedInvoice.currency)}</div>
              <div><span className="text-slate-500 block font-sans">المدفوع:</span><span className="text-emerald-600">{formatCurr(selectedInvoice.paidAmount, selectedInvoice.currency)}</span></div>
              <div><span className="text-slate-500 block font-sans">المتبقي:</span><span className="text-rose-600">{formatCurr(selectedInvoice.remainingAmount, selectedInvoice.currency)}</span></div>
            </div>

            <div className="flex justify-between items-center pt-2 border-t">
              <span className="text-[11px] text-slate-400">هذا السجل محمي ومؤرشف رسمياً لمنع التعديل العشوائي.</span>
              <div className="flex gap-2">
                <button onClick={() => { onPrintA4(selectedInvoice); setSelectedInvoice(null); }} className="px-4 py-1.5 bg-[#0097a7] text-white font-bold rounded-lg shadow-sm">
                  🖨️ طباعة الفاتورة A4
                </button>
                <button onClick={() => setSelectedInvoice(null)} className="px-4 py-1.5 bg-slate-100 text-slate-600 rounded-lg">إغلاق</button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// ==========================================
// 13. تقرير الأرباح والمبيعات للفترات
// ==========================================
function ProfitsReportWorkspace({
  invoices,
  expenses
}: {
  invoices: AlAmeenInvoice[];
  expenses: ExpenseItem[];
}) {
  const [period, setPeriod] = useState<'today' | 'week' | 'month' | 'year'>('today');

  const now = new Date();
  const todayStr = now.toISOString().split('T')[0];

  const filteredSalesInvs = invoices.filter(inv => {
    if (inv.type !== 'sale') return false;
    const invD = new Date(inv.invDate);
    if (period === 'today') return inv.invDate === todayStr;
    if (period === 'week') return (now.getTime() - invD.getTime()) / (1000 * 3600 * 24) <= 7;
    if (period === 'month') return inv.invDate.slice(0, 7) === todayStr.slice(0, 7);
    if (period === 'year') return inv.invDate.slice(0, 4) === todayStr.slice(0, 4);
    return true;
  });

  const filteredReturnInvs = invoices.filter(inv => {
    if (inv.type !== 'return') return false;
    const invD = new Date(inv.invDate);
    if (period === 'today') return inv.invDate === todayStr;
    if (period === 'week') return (now.getTime() - invD.getTime()) / (1000 * 3600 * 24) <= 7;
    if (period === 'month') return inv.invDate.slice(0, 7) === todayStr.slice(0, 7);
    if (period === 'year') return inv.invDate.slice(0, 4) === todayStr.slice(0, 4);
    return true;
  });

  const filteredExpenses = expenses.filter(exp => {
    const expD = new Date(exp.date);
    if (period === 'today') return exp.date === todayStr;
    if (period === 'week') return (now.getTime() - expD.getTime()) / (1000 * 3600 * 24) <= 7;
    if (period === 'month') return exp.date.slice(0, 7) === todayStr.slice(0, 7);
    if (period === 'year') return exp.date.slice(0, 4) === todayStr.slice(0, 4);
    return true;
  });

  const grossSales = round2(filteredSalesInvs.reduce((s, i) => s + i.grandTotal, 0));
  const totalReturns = round2(filteredReturnInvs.reduce((s, i) => s + i.grandTotal, 0));
  const netSalesRevenue = Math.max(0, round2(grossSales - totalReturns));

  const totalCost = round2(filteredSalesInvs.reduce((s, i) => s + i.rows.reduce((sum, r) => sum + round2(r.cost * r.quantity * r.factor), 0), 0));
  const grossProfit = round2(netSalesRevenue - totalCost);
  const totalExp = round2(filteredExpenses.reduce((s, e) => s + e.amount, 0));
  const netProfit = round2(grossProfit - totalExp);

  return (
    <div className="bg-white border border-slate-200 p-6 rounded-2xl space-y-4 shadow-sm text-xs">
      <div className="flex flex-wrap justify-between items-center border-b pb-3 gap-2">
        <h3 className="font-bold text-sm text-slate-800 flex items-center gap-2">
          <span className="w-3 h-3 bg-[#7b1fa2] rounded-full inline-block"></span>
          المبيعات والأرباح الصافية (المبيعات الفعلية بعد استبعاد فواتير التجار)
        </h3>
        <div className="flex gap-1.5">
          {[
            { id: 'today', name: 'اليوم' },
            { id: 'week', name: 'الأسبوع الأخير' },
            { id: 'month', name: 'هذا الشهر' },
            { id: 'year', name: 'هذه السنة' }
          ].map(p => (
            <button
              key={p.id}
              onClick={() => setPeriod(p.id as any)}
              className={`px-3 py-1.5 rounded-lg font-bold ${
                period === p.id ? 'bg-[#7b1fa2] text-white' : 'bg-slate-100 text-slate-600'
              }`}
            >
              {p.name}
            </button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-slate-50 border border-slate-200 p-4 rounded-xl">
          <span className="text-slate-500 block mb-1">صافي المبيعات الفعلية ({period}):</span>
          <span className="text-lg font-bold font-mono text-slate-900">{formatCurr(netSalesRevenue)}</span>
        </div>
        <div className="bg-slate-50 border border-slate-200 p-4 rounded-xl">
          <span className="text-slate-500 block mb-1">أرباح البضاعة المباعة:</span>
          <span className="text-lg font-bold font-mono text-[#7b1fa2]">{formatCurr(grossProfit)}</span>
        </div>
        <div className="bg-slate-50 border border-slate-200 p-4 rounded-xl">
          <span className="text-slate-500 block mb-1">المصاريف اليومية:</span>
          <span className="text-lg font-bold font-mono text-rose-600">-{formatCurr(totalExp)}</span>
        </div>
        <div className="bg-emerald-50 border border-emerald-200 p-4 rounded-xl">
          <span className="text-emerald-800 block mb-1 font-bold">صافي الربح الفعلي النهائي 🏆:</span>
          <span className="text-xl font-bold font-mono text-emerald-700">{formatCurr(netProfit)}</span>
        </div>
      </div>
    </div>
  );
}

// ==========================================
// 14. كشف حساب زبون تفصيلي تاريخي
// ==========================================
function StatementWorkspace({
  invoices,
  payments,
  onPrintStatement
}: {
  invoices: AlAmeenInvoice[];
  payments: PaymentRecord[];
  onPrintStatement: (customerName: string, customerPhone: string, invoicesList: AlAmeenInvoice[], paymentsList: PaymentRecord[], totalBilled: number, totalPaid: number, totalDebt: number) => void;
}) {
  const [searchName, setSearchName] = useState('');
  const customerInvoices = invoices.filter(i => i.type === 'sale' || i.type === 'return');
  const customerNames = Array.from(new Set(customerInvoices.map(i => i.customerName)));
  const [selectedCustomer, setSelectedCustomer] = useState(customerNames[0] || '');

  const activeName = searchName.trim() || selectedCustomer;
  const matchedInvoices = customerInvoices.filter(i => i.customerName.toLowerCase().includes(activeName.toLowerCase()));
  const matchedPayments = payments.filter(p => p.partyType === 'customer' && p.partyName.toLowerCase().includes(activeName.toLowerCase()));

  const matchedCustomerPhone = matchedInvoices[0]?.customerPhone || 'غير مسجل';
  const totalBilled = round2(matchedInvoices.reduce((s, i) => s + (i.type === 'sale' ? i.grandTotal : -i.grandTotal), 0));
  const totalPaid = round2(matchedInvoices.reduce((s, i) => s + (i.type === 'sale' ? i.paidAmount : 0), 0) + matchedPayments.reduce((s, p) => s + p.amount, 0));
  const totalDebt = Math.max(0, round2(totalBilled - totalPaid));

  return (
    <div className="bg-white border border-slate-200 p-6 rounded-2xl space-y-4 shadow-sm text-xs">
      <div className="flex justify-between items-center border-b pb-3">
        <h3 className="font-bold text-sm text-slate-800 flex items-center gap-2">
          <span className="w-3 h-3 bg-[#f06292] rounded-full inline-block"></span>
          كشف حساب تفصيلي للزبون (تاريخي كامل بجميع الفواتير والمواد والمرتجعات والدفعات)
        </h3>
        <button
          onClick={() => onPrintStatement(activeName, matchedCustomerPhone, matchedInvoices, matchedPayments, totalBilled, totalPaid, totalDebt)}
          className="bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-300 px-4 py-1.5 rounded-lg shadow-sm font-bold"
        >
          🖨️ طباعة كشف الحساب A4
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-slate-50 border border-slate-200 p-4 rounded-xl space-y-3">
          <span className="text-[#f06292] font-bold block text-sm border-b pb-2">
            👤 بطاقة تعريف الزبون (السيد:)
          </span>
          <div>
            <label className="text-slate-600 block mb-1">ابحث باسم الزبون:</label>
            <input
              type="text"
              placeholder="اكتب اسم الزبون..."
              value={searchName}
              onChange={e => setSearchName(e.target.value)}
              className="w-full bg-white border border-slate-300 rounded p-2 text-slate-900 font-bold"
            />
          </div>
          <div>
            <label className="text-slate-600 block mb-1">أو اختر من المسجلين:</label>
            <select value={selectedCustomer} onChange={e => { setSelectedCustomer(e.target.value); setSearchName(''); }} className="w-full bg-white border border-slate-300 rounded p-2">
              {customerNames.map((name, i) => (
                <option key={i} value={name}>{name}</option>
              ))}
            </select>
          </div>
          <div className="pt-2 border-t border-slate-200 space-y-1.5 font-mono">
            <p className="font-sans font-bold text-slate-900 text-base">{activeName || 'لم يتم تحديد زبون'}</p>
            <p className="text-slate-600">الهاتف: {matchedCustomerPhone}</p>
            <p className="text-slate-600">صافي المشتريات: {formatCurr(totalBilled)}</p>
            <p className="text-emerald-600 font-bold">المسدد نقداً ودفعات: {formatCurr(totalPaid)}</p>
            <div className="pt-2 border-t">
              {totalDebt > 0 ? (
                <p className="text-rose-600 font-bold text-sm">لنا عند الزبون: {formatCurr(totalDebt)}</p>
              ) : (
                <p className="text-emerald-600 font-bold text-sm">الحساب مسدد بالكامل ✓</p>
              )}
            </div>
          </div>
        </div>

        <div className="md:col-span-2 border border-slate-200 rounded-xl overflow-x-auto bg-white">
          <table className="w-full text-right text-xs">
            <thead className="bg-slate-50 text-slate-700 font-bold">
              <tr>
                <th className="p-3">التاريخ والوقت</th>
                <th className="p-3">نوع الحركة</th>
                <th className="p-3">تفاصيل المواد والكميات</th>
                <th className="p-3">مدين (لنا)</th>
                <th className="p-3">دائن (له مسدد)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-800 font-mono">
              {matchedInvoices.map(i => (
                <tr key={i.id} className={i.type === 'return' ? 'bg-rose-50/40' : ''}>
                  <td className="p-3 text-slate-500">{i.invDate} {i.invTime}</td>
                  <td className="p-3 font-sans font-bold">
                    {i.type === 'sale' ? (
                      <span className="text-slate-900">فاتورة بيع #{i.invNumber}</span>
                    ) : (
                      <span className="text-rose-600">مرتجع بضاعة #{i.invNumber}</span>
                    )}
                  </td>
                  <td className="p-3 font-sans text-slate-700">
                    {i.rows.map(r => `${r.itemName} (${r.quantity} ${r.unit})`).join('، ')}
                  </td>
                  <td className="p-3 font-bold text-slate-900">
                    {i.type === 'sale' ? formatCurr(i.grandTotal, i.currency) : '-'}
                  </td>
                  <td className="p-3 font-bold text-emerald-600">
                    {i.type === 'sale' ? formatCurr(i.paidAmount, i.currency) : formatCurr(i.grandTotal, i.currency)}
                  </td>
                </tr>
              ))}
              {matchedPayments.map(p => (
                <tr key={p.id} className="bg-emerald-50/40">
                  <td className="p-3 text-slate-500">{p.date} {p.time}</td>
                  <td className="p-3 font-sans font-bold text-emerald-800">سند قبض دفعة دين</td>
                  <td className="p-3 font-sans text-slate-600">{p.notes}</td>
                  <td className="p-3">-</td>
                  <td className="p-3 text-emerald-600 font-bold">+{formatCurr(p.amount)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

// ==========================================
// 15. الإعدادات، تكبير الخط، والنسخ الاحتياطي على الهارد
// ==========================================
function SettingsWorkspace({
  settings,
  allAppData,
  onSaveSettings,
  onRestoreFullData
}: {
  settings: AlAmeenSettings;
  allAppData: any;
  onSaveSettings: (set: AlAmeenSettings) => void;
  onRestoreFullData: (data: any) => void;
}) {
  const [conf, setConf] = useState<AlAmeenSettings>(settings);
  const [newUsername, setNewUsername] = useState(settings.adminUsername);
  const [oldPass, setOldPass] = useState('');
  const [newPass, setNewPass] = useState('');

  const handleUploadImage = (e: React.ChangeEvent<HTMLInputElement>, key: 'logoBase64' | 'stampBase64' | 'signatureBase64') => {
    const file = e.target.files?.[0];
    if (!file) return;
    const r = new FileReader();
    r.onload = ev => {
      setConf({ ...conf, [key]: ev.target?.result as string });
    };
    r.readAsDataURL(file);
  };

  const handleSaveSecurity = (e: React.FormEvent) => {
    e.preventDefault();
    if (oldPass !== conf.adminPass) {
      alert('كلمة المرور الحالية غير صحيحة!');
      return;
    }
    const updated = {
      ...conf,
      adminUsername: newUsername.trim() || conf.adminUsername,
      adminPass: newPass.trim() || conf.adminPass
    };
    setConf(updated);
    onSaveSettings(updated);
    setOldPass('');
    setNewPass('');
    alert('تم تحديث بيانات الدخول بنجاح!');
  };

  // تنزيل نسخة احتياطية محلية بصيغة JSON
  const exportFullBackup = () => {
    const backupData = {
      ...allAppData,
      settings: conf,
      backupDate: new Date().toISOString()
    };
    const blob = new Blob([JSON.stringify(backupData, null, 2)], { type: 'application/json' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = `AlAmeen_FullBackup_${new Date().toISOString().split('T')[0]}.json`;
    a.click();
  };

  // حفظ نسخة احتياطية مباشرة داخل مجلد على الهارد عبر File System Access API
  const saveDirectlyToHardDrive = async () => {
    try {
      if ('showSaveFilePicker' in window) {
        const handle = await (window as any).showSaveFilePicker({
          suggestedName: `AlAmeen_HardDisk_Backup_${new Date().toISOString().split('T')[0]}.json`,
          types: [{
            description: 'JSON Backup File',
            accept: { 'application/json': ['.json'] }
          }]
        });
        const writable = await handle.createWritable();
        const backupData = {
          ...allAppData,
          settings: conf,
          backupDate: new Date().toISOString()
        };
        await writable.write(JSON.stringify(backupData, null, 2));
        await writable.close();
        alert('تم بنجاح حفظ ملف النسخة الاحتياطية مباشرة داخل المجلد المختار على القرص الصلب!');
      } else {
        exportFullBackup();
      }
    } catch (err: any) {
      if (err.name !== 'AbortError') {
        exportFullBackup();
      }
    }
  };

  const importFullBackup = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const r = new FileReader();
    r.onload = ev => {
      try {
        const parsed = JSON.parse(ev.target?.result as string);
        onRestoreFullData(parsed);
      } catch {
        alert('ملف النسخة الاحتياطية غير صالح!');
      }
    };
    r.readAsText(file);
  };

  return (
    <div className="bg-white border border-slate-200 p-6 rounded-2xl max-w-2xl mx-auto space-y-5 shadow-sm text-xs">
      <h3 className="font-bold text-sm text-slate-800 border-b pb-2 flex items-center gap-2">
        <span className="w-3 h-3 bg-[#3949ab] rounded-full inline-block"></span>
        الإعدادات، حجم الخط، النسخ الاحتياطي والأمان
      </h3>

      <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-2">
        <span className="text-slate-800 font-bold block text-sm">🔍 تكبير حجم خط البرنامج بالكامل:</span>
        <div className="flex gap-3">
          {[
            { id: 'normal', name: 'خط عادي قياسي' },
            { id: 'medium', name: 'خط متوسط أوضح' },
            { id: 'large', name: 'خط كبير جداً للقراءة السريعة' }
          ].map(f => (
            <button
              key={f.id}
              onClick={() => {
                const updated = { ...conf, fontSize: f.id as any };
                setConf(updated);
                onSaveSettings(updated);
              }}
              className={`px-4 py-2 rounded-xl font-bold border transition-colors ${
                conf.fontSize === f.id ? 'bg-[#3949ab] text-white border-[#3949ab]' : 'bg-white text-slate-700 border-slate-300'
              }`}
            >
              {f.name}
            </button>
          ))}
        </div>
      </div>

      <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-3">
        <span className="text-emerald-800 font-bold block text-sm">💾 حفظ نسخة صلبة على القرص الصلب (Hard Disk Backup):</span>
        <p className="text-slate-500">حفظ نسخة احتياطية مباشرة على الهارد في مجلد آمن تضمن عدم فقدان البيانات حتى لو حذفت الأيقونة أو تم مسح المتصفح.</p>
        <div className="flex flex-wrap gap-3">
          <button onClick={saveDirectlyToHardDrive} className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold px-4 py-2 rounded-xl shadow-sm flex items-center gap-1.5">
            📁 حفظ ملف النسخة على الهارد
          </button>
          <button onClick={exportFullBackup} className="bg-teal-600 hover:bg-teal-700 text-white font-bold px-4 py-2 rounded-xl shadow-sm">
            📥 تنزيل ملف JSON
          </button>
          <label className="bg-slate-200 hover:bg-slate-300 text-slate-800 font-bold px-4 py-2 rounded-xl cursor-pointer flex items-center justify-center">
            📤 استعادة نسخة من ملف
            <input type="file" accept=".json" onChange={importFullBackup} className="hidden" />
          </label>
        </div>
      </div>

      <form onSubmit={handleSaveSecurity} className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-3">
        <span className="text-[#3949ab] font-bold block text-sm">🔐 تعديل اسم المستخدم وكلمة المرور وسؤال الأمان:</span>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-2">
          <div>
            <label className="text-slate-700 block mb-0.5">اسم المستخدم:</label>
            <input type="text" value={newUsername} onChange={e => setNewUsername(e.target.value)} className="w-full bg-white border border-slate-300 rounded p-1.5" />
          </div>
          <div>
            <label className="text-slate-700 block mb-0.5">كلمة المرور الحالية:</label>
            <input type="password" required value={oldPass} onChange={e => setOldPass(e.target.value)} className="w-full bg-white border border-slate-300 rounded p-1.5" />
          </div>
          <div>
            <label className="text-slate-700 block mb-0.5">كلمة المرور الجديدة:</label>
            <input type="password" value={newPass} onChange={e => setNewPass(e.target.value)} className="w-full bg-white border border-slate-300 rounded p-1.5" />
          </div>
        </div>

        <div className="grid grid-cols-2 gap-2 pt-1 border-t">
          <div>
            <label className="text-slate-700 block mb-0.5">سؤال استعادة كلمة المرور عند النسيان:</label>
            <input type="text" value={conf.securityQuestion} onChange={e => setConf({ ...conf, securityQuestion: e.target.value })} className="w-full bg-white border border-slate-300 rounded p-1.5" />
          </div>
          <div>
            <label className="text-slate-700 block mb-0.5">إجابة السؤال السرية:</label>
            <input type="text" value={conf.securityAnswer} onChange={e => setConf({ ...conf, securityAnswer: e.target.value })} className="w-full bg-white border border-slate-300 rounded p-1.5 font-bold" />
          </div>
        </div>

        <button type="submit" className="bg-[#3949ab] hover:bg-[#303f9f] text-white font-bold px-4 py-2 rounded shadow-sm">
          حفظ بيانات الدخول وسؤال الأمان
        </button>
      </form>

      <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-3">
        <span className="text-slate-800 font-bold block text-sm">🏢 بيانات المحل والفاتورة الرسمية:</span>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="text-slate-700 block mb-0.5">اسم المحل الرسمي:</label>
            <input type="text" value={conf.shopName} onChange={e => setConf({ ...conf, shopName: e.target.value })} className="w-full bg-white border border-slate-300 rounded p-1.5" />
          </div>
          <div>
            <label className="text-slate-700 block mb-0.5">رقم الهاتف:</label>
            <input type="text" value={conf.phone} onChange={e => setConf({ ...conf, phone: e.target.value })} className="w-full bg-white border border-slate-300 rounded p-1.5" />
          </div>
        </div>

        <div>
          <label className="text-slate-700 block mb-0.5">العنوان بالتفصيل:</label>
          <input type="text" value={conf.address} onChange={e => setConf({ ...conf, address: e.target.value })} className="w-full bg-white border border-slate-300 rounded p-1.5" />
        </div>

        <div>
          <label className="text-slate-700 block mb-0.5">سعر صرف الدولار مقابل الليرة:</label>
          <input type="text" value={conf.usdRate} onChange={e => setConf({ ...conf, usdRate: parseDecimal(e.target.value) || 15000 })} className="w-48 bg-white border border-slate-300 rounded p-1.5 font-mono" />
        </div>
      </div>

      <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-3">
        <span className="text-slate-800 font-bold block text-sm">🖼️ الشعار والختم والتوقيع الإلكتروني:</span>
        <div>
          <label className="text-slate-700 block mb-1">رفع شعار المحل (Logo):</label>
          <input type="file" accept="image/*" onChange={e => handleUploadImage(e, 'logoBase64')} className="w-full text-xs text-slate-500" />
          {conf.logoBase64 && (
            <div className="flex items-center gap-4 mt-2">
              <img src={conf.logoBase64} alt="Logo" className="h-10 object-contain bg-white p-1 rounded border" />
              <div className="flex items-center gap-2">
                <span className="text-slate-600">موضع الشعار على الفاتورة:</span>
                <select value={conf.logoPosition} onChange={e => setConf({ ...conf, logoPosition: e.target.value as any })} className="bg-white border border-slate-300 rounded px-2 py-1">
                  <option value="right">يمين الفاتورة</option>
                  <option value="center">وسط الفاتورة</option>
                  <option value="left">يسار الفاتورة</option>
                </select>
              </div>
            </div>
          )}
        </div>

        <div className="grid grid-cols-2 gap-3 pt-2">
          <div>
            <label className="text-slate-700 block mb-1">صورة الختم الرسمي:</label>
            <input type="file" accept="image/*" onChange={e => handleUploadImage(e, 'stampBase64')} className="w-full text-xs text-slate-500" />
            {conf.stampBase64 && <img src={conf.stampBase64} alt="Stamp" className="h-12 mt-2 object-contain bg-white p-1 rounded border" />}
          </div>
          <div>
            <label className="text-slate-700 block mb-1">صورة التوقيع الإلكتروني:</label>
            <input type="file" accept="image/*" onChange={e => handleUploadImage(e, 'signatureBase64')} className="w-full text-xs text-slate-500" />
            {conf.signatureBase64 && <img src={conf.signatureBase64} alt="Signature" className="h-10 mt-2 object-contain bg-white p-1 rounded border" />}
          </div>
        </div>

        <button onClick={() => { onSaveSettings(conf); alert('تم حفظ الإعدادات والشعار والختم بنجاح!'); }} className="w-full py-2.5 bg-[#3949ab] hover:bg-[#303f9f] text-white font-bold rounded shadow-sm mt-2">
          تثبيت وحفظ جميع الإعدادات والهوية
        </button>
      </div>
    </div>
  );
}

// ==========================================
// 16. شاشة تسجيل الدخول
// ==========================================
function AlAmeenLogin({
  onLogin,
  settings,
  onUpdateSettings
}: {
  onLogin: (u: string) => void;
  settings: AlAmeenSettings;
  onUpdateSettings: (s: AlAmeenSettings) => void;
}) {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);

  const [showForgot, setShowForgot] = useState(false);
  const [answerInput, setAnswerInput] = useState('');
  const [resetPassInput, setResetPassInput] = useState('');

  const handleResetPassword = (e: React.FormEvent) => {
    e.preventDefault();
    if (answerInput.trim().toLowerCase() === settings.securityAnswer.trim().toLowerCase()) {
      if (resetPassInput.trim().length < 4) {
        alert('كلمة المرور الجديدة يجب أن تكون 4 خانات على الأقل!');
        return;
      }
      const updated = { ...settings, adminPass: resetPassInput.trim() };
      onUpdateSettings(updated);
      alert('تم التحقق بنجاح! تم تعيين كلمة المرور الجديدة. يمكنك الدخول بها الآن.');
      setPassword(resetPassInput.trim());
      setShowForgot(false);
      setAnswerInput('');
      setResetPassInput('');
    } else {
      alert('إجابة سؤال الأمان غير صحيحة!');
    }
  };

  return (
    <div className="min-h-screen bg-slate-100 flex items-center justify-center p-4 font-sans text-right" dir="rtl">
      <div className="bg-white border border-slate-200 w-full max-w-sm p-8 rounded-3xl shadow-xl space-y-5">
        <div className="text-center space-y-2">
          <div className="w-16 h-16 bg-[#0097a7] rounded-2xl flex items-center justify-center text-white text-3xl mx-auto shadow-md">
            🏛️
          </div>
          <h2 className="text-lg font-bold text-slate-900">برنامج الأمين للمحاسبة والمستودعات</h2>
          <p className="text-xs text-slate-500">إصدار الأدوات الصحية والكهربائية والخردة</p>
        </div>

        {!showForgot ? (
          <form
            onSubmit={e => {
              e.preventDefault();
              if (username.trim() === settings.adminUsername && password.trim() === settings.adminPass) {
                onLogin(username);
              } else {
                alert('خطأ في اسم المستخدم أو كلمة المرور!');
              }
            }}
            className="space-y-4 text-xs"
          >
            <div>
              <label className="text-slate-700 block mb-1 font-bold">اسم المستخدم:</label>
              <input
                type="text"
                required
                placeholder="أدخل اسم المستخدم..."
                value={username}
                onChange={e => setUsername(e.target.value)}
                className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 text-slate-900 font-bold"
                autoFocus
              />
            </div>
            <div>
              <label className="text-slate-700 block mb-1 font-bold">كلمة المرور:</label>
              <div className="relative">
                <input
                  type={showPassword ? 'text' : 'password'}
                  required
                  placeholder="أدخل كلمة المرور..."
                  value={password}
                  onChange={e => setPassword(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 text-slate-900 font-bold pl-10"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute left-2.5 top-2.5 text-slate-400 hover:text-slate-700 font-bold text-xs"
                >
                  {showPassword ? 'إخفاء 🙈' : 'إظهار 👁️'}
                </button>
              </div>
            </div>
            <button type="submit" className="w-full py-3 bg-[#0097a7] hover:bg-[#00838f] text-white font-bold rounded-xl shadow-md text-sm transition-colors">
              دخول لملف الشركة (Enter)
            </button>
            <div className="flex justify-between items-center text-[11px] pt-1">
              <span className="text-slate-400">نظام محاسبي آمن 100%</span>
              <button type="button" onClick={() => setShowForgot(true)} className="text-[#0097a7] font-bold hover:underline">
                نسيت كلمة المرور؟
              </button>
            </div>
          </form>
        ) : (
          <form onSubmit={handleResetPassword} className="space-y-3 text-xs">
            <div className="bg-amber-50 p-3 rounded-xl border border-amber-200 text-amber-900 font-bold">
              سؤال الأمان لاستعادة الحساب: {settings.securityQuestion}
            </div>
            <div>
              <label className="text-slate-700 block mb-1">الإجابة السرية:</label>
              <input
                type="text"
                required
                placeholder="اكتب الإجابة..."
                value={answerInput}
                onChange={e => setAnswerInput(e.target.value)}
                className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 font-bold"
              />
            </div>
            <div>
              <label className="text-slate-700 block mb-1">كلمة المرور الجديدة:</label>
              <input
                type="password"
                required
                placeholder="أدخل كلمة مرور جديدة..."
                value={resetPassInput}
                onChange={e => setResetPassInput(e.target.value)}
                className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 font-bold"
              />
            </div>
            <div className="flex gap-2 pt-1">
              <button type="button" onClick={() => setShowForgot(false)} className="px-4 py-2 bg-slate-100 text-slate-700 font-bold rounded-xl">
                إلغاء
              </button>
              <button type="submit" className="flex-1 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl shadow">
                استعادة وتعيين كلمة المرور
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
}